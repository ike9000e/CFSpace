#include "fu2_main.h"
#include <memory>
#include "fu2_ulcfg.h"

static_assert( sizeof(WCHAR)==2, "" );
static_assert( sizeof(TCHAR)==1, "" );

int main( int argc, const char*const* argv )
{
/*
	const char* ts2 = "xx SLUS_123.45--";
//	const char* ts2 = "xx SLUS_12345--";
//	const char* ts2 = "xx SLUS12345";
//	const char* ts2 = "xx SLUS123.45";
//	const char* ts2 = "xx SLUSx_123.45--"; // must fail.
	std::pair<size_t,size_t> pos2;
	std::pair<std::string,uint32_t> aGmid;
	std::string srGmId, srNewTitle;
	bool res2 = fu_GetPs2GameIdFromData(
			ts2, strlen(ts2), &aGmid, &pos2, &srGmId, &srNewTitle );
	printf("GmId: %d [%s++%05u] (%d,%d) '%s' t:'%s'\n", (int)res2,
			aGmid.first.c_str(), aGmid.second,
			(int)pos2.first, (int)pos2.second, srGmId.c_str(),
			srNewTitle.c_str() );
	return 255;//*/
/*
	std::vector<FU_DiskVolume> dvls;
	fu_EnumeratePhysicalDrives( &dvls );
	for( const auto& dv3 : dvls ){
		printf("Disk %d\n", dv3.nOrderNr );
		printf("\t""srShortName  : [%s]\n", dv3.srShortName.c_str() );
		printf("\t""srPath       : [%s]\n", dv3.srPath.c_str() );
		printf("\t""srErrorIfAny : [%s]\n", dv3.srErrorIfAny.c_str() );
		printf("\t""srVolLabel   : [%s]\n", dv3.srVolLabel.c_str() );
		printf("\t""srFSName     : [%s]\n", dv3.srFSName.c_str() );
		printf("\t""uSectorSize  : %d\n", (int)dv3.uSectorSize );
		printf("\t""bAccessible  : %d\n", (int)dv3.bAccessible );
	}
	return 255;//*/
/*
	printf("int-max: %d\n", HfLimits<int>::max_() );
	printf("int-min: %d\n", HfLimits<int>::min_() );
	printf("u32-min: %d\n", (int)HfLimits<uint32_t>::min_() );
	printf("u32-max: 0x%X\n", (int)HfLimits<uint32_t>::max_() );
	return 255;//*/

	assert( !FU_OpenedDisk );
	assert( !FU_Params2 );
	FU_Params2 = new FU_AppParams;
	std::shared_ptr<void> raii2( 0, [&](void*){
		if(FU_Params2){
			delete FU_Params2;
			FU_Params2 = 0;
		}
	});
	std::string srCrcUl, srUlCfgAdd;
	for( int ii2 = 1; ii2 < argc; ii2++ ){
		const char* arg2 = argv[ii2];
		if(0){
		}else if( !strcmp( arg2, "--open_disk" ) && ii2+1 < argc ){
			FU_Params2->srInitialDiskOpen = argv[++ii2];
		}else if( !strcmp( arg2, "--read_only" ) && ii2+1 < argc ){
			FU_Params2->bOpenReadOnly = !!atoi( argv[++ii2] );
		}else if( !strcmp( arg2, "--current_dir" ) && ii2+1 < argc ){
			FU_Params2->srInitialCurDir = argv[++ii2];
		}else if( !strcmp( arg2, "--error_exit" ) ){
			FU_Params2->bExitOnCmdError = 1;
		}else if( !strcmp( arg2, "--buff_rw_size" ) && ii2+1 < argc ){
			FU_Params2->uBuffRWSize = std::strtoul( argv[++ii2], 0, 10 );
		}else if( !strcmp( arg2, "--run_cmd" ) && ii2+1 < argc ){
			FU_Params2->srRunCmd = argv[++ii2];
		}else if( !strcmp( arg2, "--crc_ul" ) && ii2+1 < argc ){
			srCrcUl = argv[++ii2];
		}else if( !strcmp( arg2, "--disk_reinit_w" ) ){
			FU_Params2->bDiskReinitOnWriteEnd = 1;
		}else if( !strcmp( arg2, "--no_disk_reinit_w" ) ){
			FU_Params2->bDiskReinitOnWriteEnd = 0;
		}else if( !strcmp( arg2, "--write_sync" ) ){
			FU_Params2->bSyncOnBfrWrite = 1;
		}else if( !strcmp( arg2, "--no_write_sync" ) ){
			FU_Params2->bSyncOnBfrWrite = 0;
		}else if( !strcmp( arg2, "--ul_cfg_add" ) && ii2+1 < argc ){
			srUlCfgAdd = argv[++ii2];
		}
	}
	{
		if( !srCrcUl.empty() ){  //--crc_ul
			printf("Generating CRC for Title (Related to 'ul.cfg' - OPL / USBAdvance).\n");
			uint32_t crc2 = fu_GetUsbAdvanceULCrc32( srCrcUl.c_str() );
			printf("Title    : [%s]\n", srCrcUl.c_str() );
			printf("CRC(hex) : %08x\n", crc2 );
			return 0;
		}
		if( !srUlCfgAdd.empty() ){  //--ul_cfg_add
			printf("Adding game title to 'ul.cfg' in current directory.\n");
			std::string srUlCfgFn = (hf_getcwd() + "/ul.cfg"), err2;
			bool rs2 = FU_CmdUlInject::addUlCfgTitleFromText(
					srUlCfgAdd, srUlCfgFn.c_str(), &err2 );
			//if(!rs2)
			printf("[%s]\n", err2.c_str() );
			return (rs2 ? 0 : 102);
		}
	}
	if( !FU_Params2->srInitialDiskOpen.empty() ){
		printf("INFO: Opening disk on startup...\n");
		FU_CmdOpen::openDiskOnStartup(
				std::string(FU_Params2->srInitialDiskOpen.c_str()).c_str(),
				FU_Params2->bOpenReadOnly,
				FU_Params2->srInitialCurDir.c_str() );
	}
	{
	/*	//FILE* fp2 = fopen( FU_Params2->srInitialDiskOpen.c_str(), "rb" );
		const char* sz2 = "";
		FILE* fp2 = fopen( sz2, "rb" );
		assert( fp2 );
		{
			// 2147483646, 2147483647, 2147483648, 2147483649
			// 2988767241, 2988769280, 2988769281
			bool rs3 = hf_Seek64( fp2, 2988767241 );
			assert( rs3 );
			{
				std::vector<uint8_t> bfr2;
				bfr2.resize( 4, 0u );
				fread( &bfr2[0], bfr2.size(), 1, fp2 );
				printf("bytes: %02X,%02X,%02X,%02X\n", bfr2[0], bfr2[1], bfr2[2], bfr2[3] );
			}
		}
		fclose( fp2 );
		fp2 = 0;//*/
	}
	bool rs2 = fu_EnterCmdLoop();
	printf("INFO: Program exit.\n");
	return ( rs2 ? 0 : 102 );
}

