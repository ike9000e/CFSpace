#include "fu2_ulcfg.h"
#include <cctype>    //std::isalpha()
#include <memory> //shared_ptr

std::vector<uint8_t> FU_CmdUlInject::
createUlCfgEntry( const char* szTitle, std::string srGameIdWthDot ) //static
{
	assert( szTitle );
	assert( *szTitle );
	assert( !srGameIdWthDot.empty() );
	assert( srGameIdWthDot.size() == 11 );  //eg. "SLUS_123.45"
	std::vector<uint8_t> outp;
	size_t len2 = std::min<size_t>( 31, std::strlen( szTitle ) );
	for( size_t ii2 = 0; ii2 < len2; ii2++ ){
		outp.push_back( static_cast<char>( szTitle[ii2] ) );
	}
	outp.resize( 32, 0 );
	// eg. "ul.SLUS_209.46"
	static const std::string data2 = "ul.";
	static const std::vector<uint8_t> data3 = { 0, 0x05, 0x14, 0,0,0,0, 0x08, };
	outp.insert( outp.end(), data2.begin(), data2.end() );
	outp.insert( outp.end(), srGameIdWthDot.begin(), srGameIdWthDot.end() );
	outp.insert( outp.end(), data3.begin(), data3.end() );
	assert( outp.size() == 54 );
	outp.resize( 64, 0 );
	return outp;
}
/// Extracts PS2 game-id from input string.
/// Extracted is first encountered match.
/// Finds fe.: "SLUS_123.45".
///            "SLUS12345".
///            "SLUS_12345".
///         or "SLUS123.45",
///    bot not "SLUSx_123.45".
/// \param outp - optional, returns game-id as a string/value pair.
///               Eg. string, the first member, is set to "SLUS"
///               and value, the second member, is set to 12345.
/// \param aPosEnd - optional, position where id has been found. begin and end index.
/// \param srGameIdWithDotOut - optional, reconstructed game-id as string.
/// \param srNewTitleOut - optional, new title that is made of all
///                        characters excluding extracted game-id.
///                        if used, input data in 'inp' should
///                        consist of text characters only, ie. it should have been c-string.
/// \sa fu_GetPs2GameIdFromData2().
bool fu_GetPs2GameIdFromData(
		const void* inp_, uint64_t uNumBytes,
		std::pair<std::string,uint32_t>* outp,
		std::pair<size_t,size_t>* aPosEnd,
		std::string* srGameIdWithDotOut,
		std::string* srNewTitleOut )
{
	const uint8_t* inp = (const uint8_t*) inp_;
	std::string letters2, digits2;
	static const char* szTrimChars = "_-.\x20";
	std::pair<std::string,uint32_t> outp3, *outp2 = ( outp ? outp : &outp3 );
	std::pair<size_t,size_t> aPosEnd3, *aPosEnd2 = ( aPosEnd ? aPosEnd : &aPosEnd3 );
	*aPosEnd2 = { uNumBytes, uNumBytes, };
	for( size_t ii2=0; ii2 < uNumBytes; ii2++ ){
		if( ii2 && ii2+1 < uNumBytes ){  // detect if no at the begin and non-alpha-char leads alpth-char.
			if( !std::isalpha( inp[ii2+0] ) && std::isalpha( inp[ii2+1] ) ){
				ii2 += 1;
			}else{
				continue;
			}
		}
		if( ii2+5 < uNumBytes ){
			bool bOk2 = (
				std::isalpha( inp[ii2+0] ) &&
				std::isalpha( inp[ii2+1] ) &&
				std::isalpha( inp[ii2+2] ) &&
				std::isalpha( inp[ii2+3] ) &&
				!std::isalpha( inp[ii2+4] ) );
			if(bOk2){
				{
					letters2.resize( 4 );
					std::memcpy( &letters2[0], &inp[ii2], 4 );
					assert( letters2.size() == 4 );
				}
				aPosEnd2->first = ii2;
				ii2 += 4;
				ii2 += ( std::strchr(szTrimChars, inp[ii2] ) ? 1 : 0 );
				if( ii2+3 < uNumBytes ){ // part "123.45" or "12345".
					bool bOk3 = (
						std::isdigit( inp[ii2+0] ) &&
						std::isdigit( inp[ii2+1] ) &&
						std::isdigit( inp[ii2+2] ) );
					if( bOk3 ){
						{
							//digits2.insert( digits2.end(), inp.begin() + ii2, inp.begin() + ii2+3 );
							digits2.resize( 3 );
							std::memcpy( &digits2[0], &inp[ii2], 3 );
						}
						ii2 += 3;
						ii2 += ( inp[ii2] == '.' ? 1 : 0 );
						if( ii2+1 < uNumBytes ){
							bool bOk4 = (
								std::isdigit( inp[ii2+0] ) &&
								std::isdigit( inp[ii2+1] ) );
							if( bOk4 ){
								aPosEnd2->second = ii2+2;
								{
									//digits2.insert( digits2.end(), inp.begin() + ii2, inp.begin() + ii2+2 );
									digits2.resize( digits2.size()+2 );
									std::memcpy( &digits2[digits2.size()-2], &inp[ii2], 2 );
								}
								break;
							}
						}
					}
				}
			}
		}
	}
	*outp2 = {
		letters2,
		static_cast<uint32_t>( std::strtoul( digits2.c_str(), 0, 10 ) ), };
	if( srGameIdWithDotOut ){
		char bfrA[16], bfrB[16];
		std::sprintf( bfrA, "%03u", uint32_t(outp2->second / 100) );
		std::sprintf( bfrB, "%02u", uint32_t(outp2->second % 100) );
		assert( std::strlen(bfrA) == 3 );
		assert( std::strlen(bfrB) == 2 );
		*srGameIdWithDotOut = HfArgs("%1_%2.%3")
				.arg( outp2->first.c_str() )
				.arg( bfrA )
				.arg( bfrB ).c_str();
	}
	if( srNewTitleOut ){
		const char* bgn2 = (const char*) inp;
		const char* bgn3 = (const char*) &inp[aPosEnd2->second];
		const char* end3 = reinterpret_cast<const char*>(
				std::memchr( &bgn2[aPosEnd2->second], '\0',
						(uNumBytes - aPosEnd2->second) ) );
		end3 = ( end3 ? end3 : (const char*)( &bgn2[uNumBytes] ) );
		std::string a, b;
		a.assign( bgn2, aPosEnd2->first );
		b.assign( bgn3, end3-bgn3 );
		*srNewTitleOut = fu_StrJoinAutoGlue( a, b, 0, nullptr );
		static_assert( sizeof(decltype(*inp)) == sizeof(decltype(*bgn2)), "");
	}
	return !digits2.empty();
}

/// Gets game-id.
/// \sa fu_GetPs2GameIdFromData().
/// On error, return value's member 'uIdPart' is set to zero.
FU_GameId fu_GetPs2GameIdFromData2( const void* inp, uint64_t uNumBytes, int flags2 )
{
	std::pair<std::string,uint32_t> aStrId;
	FU_GameId outp;
	fu_GetPs2GameIdFromData( inp, uNumBytes,
			&aStrId, &outp.aPosEnd, &outp.srGameIdWithDot,
			(flags2 & FU_GIGetNewTitle ? &outp.srNewTitle : nullptr ) );
	outp.srStrPart = aStrId.first;
	outp.uIdPart   = aStrId.second;
	return outp;
}
/// Gets game-id from file given file name.
/// \sa fu_GetPs2GameIdFromData2().
FU_GameId fu_GetPs2GameIdFromFile( const char* szFname, uint64_t uMaxHdrRead )
{
	uMaxHdrRead = ( uMaxHdrRead ? uMaxHdrRead : 1024*1024 );
	std::vector<uint8_t> data2;
	hf_ReadFileBytes64Fn( szFname, 0, uMaxHdrRead, &data2 );
	FU_GameId outp;
	outp = fu_GetPs2GameIdFromData2( &data2[0], data2.size(), 0 );
	return outp;
}

/// Adds game entry to the "ul.cfg" file.
/// Does not check if same entry already exists.
/// \param srTitlePlusGmId -
///              expected to contain game title and title-id.
///              eg. "GT4 Concept SLUS_123.45"
/// \param srUlCfgPath - path to the "ul.cfg" file.
/// \param err         - optional, message on error.
bool FU_CmdUlInject::
addUlCfgTitleFromText( std::string srTitlePlusGmId, std::string srUlCfgPath, std::string* err )
{
	std::string err3, *err2 = (err ? err : &err3);

	std::pair<size_t,size_t> aBgnEnd;
	std::string srGmId;
	if( !fu_GetPs2GameIdFromData( srTitlePlusGmId.c_str(), srTitlePlusGmId.size(), 0, &aBgnEnd, &srGmId, 0 ) ){
		*err2 = "Game title ID not found.";
		return 0;
	}
	std::string srTitle;
	{
		std::string a, b;
		a = srTitlePlusGmId.substr( 0, aBgnEnd.first );
		b = srTitlePlusGmId.substr( aBgnEnd.second, std::string::npos );
		srTitle = fu_StrJoinAutoGlue( a, b, 0, nullptr );
	}
	if( srTitle.empty() ){
		*err2 = "Game title yields empty text.";
		return 0;
	}
	return addUlCfgTitleFS( srTitle, srGmId, srUlCfgPath, err2 );
}

bool FU_CmdUlInject::
addUlCfgTitleFS( std::string srTitle, std::string srGameId,
		std::string srUlCfgPath, std::string* err )
{
	std::string err3, *err2 = (err ? err : &err3);
	if( !hf_FileExists( srUlCfgPath.c_str() ) ){
		*err2 = "File not found.";
		return 0;
	}
	auto aEntry = createUlCfgEntry( srTitle.c_str(), srGameId.c_str() );
	if( aEntry.empty() ){
		*err2 = "Failed creating config entry [e25GMhZ]";
		return 0;
	}
	bool rs2 = hf_PutFileBytes( srUlCfgPath.c_str(),
			&aEntry[0], (int)aEntry.size(), HF_EPFBF_APPEND );
	if(!rs2){
		*err2 = "Failed writing file data.";
		return 0;
	}
	*err2 = "OK.";
	return 1;
}
/**
	Adds entry to ul.cfg on currently opened disk.
*/
bool FU_CmdUlInject::
addUlCfgTitleD2( std::string srTitle, std::string srGameIdWithDot2, std::string srUlCfgPath, std::string* err )
{
	std::string err3, *err2 = (err ? err : &err3);
	std::pair<bool,FIL> fi3( 0, FIL() ); FRESULT rs2;
	std::shared_ptr<void> raii3( 0, [&](void*){
		if( fi3.first ){
			f_close( &fi3.second );
			fi3.first = 0;
		}
	});
	rs2 = f_open( &fi3.second, srUlCfgPath.c_str(), FA_WRITE|FA_OPEN_ALWAYS );
	if( rs2 != FR_OK ){
		*err2 = "Failed opening disk file [lytc2L2]";
		return 0;
	}
	fi3.first = 1;
	std::vector<uint8_t> aEntry;
	aEntry = createUlCfgEntry( srTitle.c_str(), srGameIdWithDot2.c_str() );
	if( aEntry.empty() ){
		*err2 = "Failed creating config entry [30LsHV4o]";
		return 0;
	}
	FSIZE_t uFsize = f_size( &fi3.second );
	rs2 = f_lseek( &fi3.second, uFsize );
	if( rs2 != FR_OK ){
		*err2 = "Failed moving file pointer [fMpb3gD]";
		return 0;
	}
	UINT nToWrite = static_cast<UINT>(aEntry.size()), nWritten = 0;
	rs2 = f_write( &fi3.second, &aEntry[0], nToWrite, &nWritten );
	if( rs2 != FR_OK || nWritten != nToWrite ){
		*err2 = HfArgs("Failed writting bytes to file. Written %1/%2 [g5ObGO]")
				.arg(nWritten)
				.arg(nToWrite).c_str();
		return 0;
	}
	return 1;
}

bool FU_CmdUlInject::exec2()
{
	bool bAllocatedAll = 0, bUserCancel = 0;
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened.\n");
		return 0;
	}
	std::string srIsoFname, srGameIdWithDot2;
	uint32_t uPartSize = FU_UlUsbAdvanceSplitSize;
	bool bUpdateUlCfg = 1;
	{
		const auto endd = CmdArgs.aArgs.end();
		for( auto a = CmdArgs.aArgs.begin(); a != endd; ++a ){
			if( *a == "-s" && a+1 != endd ){
				++a;
				auto size2 = strtoul( a->c_str(), 0, 10 );
				uPartSize = size2 ? static_cast<uint32_t>( size2 ) : uPartSize;
			}else if( *a == "-b" ){
				bUpdateUlCfg = 0;
			}else if( *a == "-i" && a+1 != endd ){
				++a;
				FU_GameId gmid;
				gmid = fu_GetPs2GameIdFromData2( a->c_str(), a->size(), 0 );
				if( gmid.uIdPart ){
					assert( gmid.srGameIdWithDot.size() == 11 );
					srGameIdWithDot2 = gmid.srGameIdWithDot;
				}
			}else if( srIsoFname.empty() ){
				srIsoFname = *a;
			}
		}
	}
	if( srIsoFname.empty() ){
		printf("ERROR: No input ISO file on the command line.\n" );
		return 0;
	}
	if( !hf_FileExists( srIsoFname.c_str() ) ){
		printf("ERROR: Input ISO file not found.\n" );
		printf("       [%s]\n", srIsoFname.c_str() );
		return 0;
	}
	std::string srTitle;
	uint32_t uTitleCrc32;
	{
		std::string srBname2 = std::get<0>(
				hf_basename3<char>( srIsoFname.c_str(), 0, 128 ) );
		if( srGameIdWithDot2.empty() ){
			//printf("Searching for game-id in file name.\n");
			FU_GameId gmid2;
			gmid2 = fu_GetPs2GameIdFromData2( srBname2.c_str(), srBname2.size(), FU_GIGetNewTitle );
			if( gmid2.uIdPart ){
				srGameIdWithDot2 = gmid2.srGameIdWithDot;
				srTitle          = gmid2.srNewTitle;
			}else{
				//printf("Searching for game-id in file bytes.\n");
				gmid2 = fu_GetPs2GameIdFromFile( srIsoFname.c_str(), 0 );
				if( gmid2.uIdPart ){
					srGameIdWithDot2 = gmid2.srGameIdWithDot;
					srTitle          = srBname2;
				}else{
					printf("ERROR: Failed to obtain game-id.\n" );
					printf("       Not found in either ISO mane or file contents.\n");
					printf("       Use '-i' switch to set it manually.\n");
					printf("       [%s]\n", srIsoFname.c_str() );
					return 0;
				}
			}
		}else{
			srTitle = srBname2;
		}
		if( srTitle.empty() ){
			printf("ERROR: Couldn't determine game title from ISO file name.\n" );
			printf("       [%s]\n", srIsoFname.c_str() );
			return 0;
		}
		uTitleCrc32 = fu_GetUsbAdvanceULCrc32( srTitle.c_str() );
	}
	uint32_t uNumParts; FSIZE_t uLastPartSize;
	{
		uint64_t fsize2 = hf_GetFileSize64Fn( srIsoFname.c_str() );
		if( !fsize2 ){
			printf("ERROR: Input ISO file seems to be empty.\n" );
			printf("       [%s]\n", srIsoFname.c_str() );
			return 0;
		}
		uLastPartSize = static_cast<uint32_t>( fsize2 % uPartSize );
		uLastPartSize = ( uLastPartSize ? uLastPartSize : uPartSize );
		uNumParts     = static_cast<uint32_t>( fsize2 / uPartSize + !!( fsize2 % uPartSize ) );
	}
	if( uNumParts > 32 ){
		printf("ERROR: Number of parts ends up being more than 32.\n");
		printf("       This is a sanity limit.\n");
		return 0;
	}
	if( !uNumParts ){
		printf("ERROR: No files to create [0Ns6io]\n");
		return 0;
	}
	std::vector<FU_UlPartFile> aNewFiles;
	std::shared_ptr<void> raii2( 0, [&](void*){
		if( !bAllocatedAll || bUserCancel ){
			for( auto a = aNewFiles.begin(); a != aNewFiles.end(); ++a ){
				if( a->bAllocated2 ){
					printf("Deleting empty, incomplete part-file [%s]...\n", a->srBname.c_str() );
					FU_CmdDelete::deleteFile( a->srPathname.c_str(), 0 );
					a->bAllocated2 = 0;
				}
			}
		}
	});
	assert( srGameIdWithDot2.size() == 11 );
	for( uint32_t ii2 = 0; ii2 < uNumParts; ii2++ ){
		bool bLast = ( ii2+1 == uNumParts );
		char bfrFname[256];
		// eg. "ul.51EDB881.SCUS_973.28.00"
		snprintf( bfrFname, sizeof(bfrFname),
				"ul.%08X.%s.%02d",
				uTitleCrc32, srGameIdWithDot2.c_str(), ii2 );
		FU_UlPartFile pf2;
		pf2.uFSize     = ( bLast ? uLastPartSize : uPartSize );
		pf2.srBname    = bfrFname;
		pf2.addr2      = uPartSize * ii2;
		pf2.srPathname = FU_OpenedDisk->getCDPathTo( bfrFname );
		aNewFiles.push_back( pf2 );
	}
	printf("Game Title          : [%s]\n", srTitle.c_str() );
	printf("Num files to create : [%d]\n", (int)aNewFiles.size() );
	printf("First file          : [%s]\n", aNewFiles[0].srBname.c_str() );
	for( uint32_t ii2 = 0; ii2 < uNumParts; ii2++ ){
		assert( ii2 < aNewFiles.size() );
		auto& aNew = aNewFiles[ii2];
		std::string prefix3 = HfArgs("%1/%2\x20")
				.arg( ii2+1 )
				.arg( uNumParts ).c_str();
		bool rs2;
		assert( aNew.uFSize );
		rs2 = FU_CmdMkfile::createAllocFile( aNew.srPathname.c_str(),
					aNew.uFSize, nullptr, 0 );
		if(!rs2){
			return 0;
		}
		aNew.bAllocated2 = 1;
	}
	bAllocatedAll = 1;
	{
		printf("\n");
		printf("Space allocated successfully.\n");
		printf("Press ENTER to continue or C to cancel now: ");
		char bfr[1024]; std::string ans2;
		if( !std::fgets( bfr, sizeof(bfr), stdin ) ){
			printf("ERROR: fgets() failed [ZkTt8Y4Q]\n");
		}
		ans2 = hf_rtrim_stdstring( bfr, "\r\n\x20");
		if( std::strpbrk( ans2.c_str(), "cC" ) ){
			bUserCancel = 1;
			return 0;
		}
	}
	for( uint32_t ii2 = 0; ii2 < uNumParts; ii2++ ){
		const auto& aNew = aNewFiles[ii2];
		std::string prefix3 = HfArgs("%1/%2\x20")
				.arg( ii2+1 )
				.arg( uNumParts ).c_str();
		bool rs2;
		assert( aNew.uFSize );
		rs2 = FU_CmdInject::injectFile(
				srIsoFname, aNew.srPathname,
				0, // 0 = create not contiguous. 0 because it's as such already.
				1,
				prefix3.c_str(), aNew.addr2, {1,uint64_t(aNew.uFSize),},
				1 );
		if( !rs2 ){
			//printf("ERROR: Failed creating disk file [FO5kiQS]\n");
			return 0;
		}
	}
	if( bUpdateUlCfg ){
		auto srUlCfgFname = FU_OpenedDisk->getCDPathTo("ul.cfg");
		printf("INFO: Adding entry to ul.cfg\n");
		std::string err2;
		if( !addUlCfgTitleD2( srTitle, srGameIdWithDot2, srUlCfgFname.c_str(), &err2 ) ){
			printf("ERROR: Failed adding title to ul.cfg [pGbjFalR]\n");
			printf("       [%s].\n", err2.c_str() );
			return 0;
		}
	}
	return 1;
}

FRESULT
fu_ParseUlCfgFileD2( const char* szUlCfgFname, std::vector<FU_UlCfgEn>* outp, std::string* err )
{
	std::string err3, *err2 = (err ? err : &err3);
	FRESULT rs2; FIL fi2;
	std::memset( &fi2, 0, sizeof(fi2) );
	outp->clear();
	std::shared_ptr<void> raii4( 0, [&](void*){
		if( fi2.obj.fs ){
			f_close( &fi2 );
			fi2.obj.fs = 0;
		}
	});
	if( FR_OK != (rs2 = f_open( &fi2, szUlCfgFname, FA_READ|FA_OPEN_EXISTING )) ){
		if( rs2 == FR_NO_FILE ){
			*err2 = "File ul.cfg not found [6gLbZx7]";
		}else{
			*err2 = "Failed opening ul.cfg file [hlP5lwo]";
		}
		return rs2;
	}
	assert( fi2.obj.fs );
	FSIZE_t fsize2 = f_size( &fi2 );
	if( !fsize2 ){
		return FR_OK;  //ok, file is empty, returs no entries.
	}
	if( FR_OK != (rs2 = f_lseek( &fi2, 0 )) ){
		*err2 = "File seek failed [x6qWed]";
		return rs2;
	}
	UINT br2 = 0;
	std::vector<uint8_t> bfr2;
	bfr2.resize( fsize2, 0 );
	rs2 = f_read( &fi2, &bfr2[0], fsize2, &br2 );
	if( rs2 != FR_OK || br2 != fsize2 ){
		*err2 = "Failed reading ul.cfg file [6ycNBnW]";
		rs2 = ( rs2 != FR_OK ? rs2 : FR_INT_ERR );
		return rs2;
	}
	for( size_t ii2 = 0; ii2+64 <= bfr2.size(); ii2 += 64 ){
		FU_UlCfgEn ulc2;
		for( size_t ii3 = 0; ii3 < 32 && bfr2[ii2+ii3]; ii3++ ){
			char chr = static_cast<char>( bfr2[ii2+ii3] );
			ulc2.srTitle2.append( &chr, 1 );
		}
		if( ulc2.srTitle2.empty() ){
			*err2 = HfArgs("Empty game title at file offset %1(d) [SgXOE9Z]")
					.arg(ii2).c_str();
			return FR_INVALID_OBJECT;
		}
		for( size_t ii3 = 35; ii3 < 35+11 && bfr2[ii2+ii3]; ii3++ ){
			char chr = static_cast<char>( bfr2[ii2+ii3] );
			ulc2.srIdStr.append( &chr, 1 );
		}
		FU_GameId gmid4;
		gmid4 = fu_GetPs2GameIdFromData2( ulc2.srIdStr.c_str(), ulc2.srIdStr.size(), 0 );
		if( !gmid4.uIdPart ){
			*err2 = HfArgs("Invalid game id at file offset %1(d) [jVk5GQa]")
					.arg(ii2+35).c_str();
			return FR_INVALID_OBJECT;
		}
		assert( gmid4.srGameIdWithDot.size() == 11 );
		ulc2.srIdStr = gmid4.srGameIdWithDot;
		for( size_t ii3 = 46; ii3 < 64; ii3++ ){
			uint8_t bt2 = bfr2[ii2+ii3];
			ulc2.aUlBytes.push_back( bt2 );
		}
		assert( ulc2.aUlBytes.size() == 18 );
		outp->push_back( ulc2 );
	}
	return FR_OK;
}
bool FU_CmdUlList::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened [MPaeHsXk]\n");
		return 0;
	}
	bool bShowLong = 0;
	for( const auto& a : CmdArgs.aArgs ){
		if( a == "-l" ){
			bShowLong = 1;
		}
	}
	std::string srUlCfg = FU_OpenedDisk->getCDPathTo("ul.cfg");
	FRESULT rs2;
	std::string err2;
	std::vector<FU_UlCfgEn> entries2;
	if( FR_OK != (rs2 = fu_ParseUlCfgFileD2( srUlCfg.c_str(), &entries2, &err2 )) ){
		printf("ERROR: %s. Code:%d [8XKLGu5]\n", err2.c_str(), rs2 );
		return 0;
	}
	int ii2 = 0;
	for( auto a = entries2.begin(); a != entries2.end(); ++a, ii2++ ){
		std::string srNr = HfArgs("*%1").arg(ii2+1).c_str();
		srNr = ( std::string( std::max<int>( 4-int(srNr.size()), 0 ), '\x20') ) + srNr;
		if( !bShowLong ){
			printf("%s: %s\n", srNr.c_str(), a->srTitle2.c_str() );
		}else{
			printf("%s: [%s]\n", srNr.c_str(), a->srTitle2.c_str() );
			printf("%s[%s]\n", "\x20\x20\x20\x20\x20\x20", a->srIdStr.c_str() );
		}
	}
	return 1;
}
std::vector<uint8_t>
fu_CreateUlCfgFileData( const std::vector<FU_UlCfgEn>& entries5 )
{
	std::vector<uint8_t> outp;
	std::vector<FU_UlCfgEn>::const_iterator a;
	for( a = entries5.begin(); a != entries5.end(); ++a ){
		size_t ii2 = 0;
		for( ; ii2 < a->srTitle2.size() && ii2 < 32; ii2++ ){
			outp.push_back( static_cast<uint8_t>( a->srTitle2[ii2] ) );
		}
		for( ; ii2 < 32; ii2++ ){
			outp.push_back( 0x00 );
		}
		std::string srUlIdStr = (std::string("ul.") + a->srIdStr);
		assert( srUlIdStr.size() == 14 );
		for( auto b : srUlIdStr ){
			outp.push_back( static_cast<uint8_t>( b ) );
		}
		assert( a->aUlBytes.size() == 18 );
		for( auto c : a->aUlBytes ){
			outp.push_back( c );
		}
	}
	if( (outp.size() % 64) != 0 ){
		assert(0);
	}
	return outp;
}
/**
	Generates checksum that goes into ul.cfg and ties game entry
	with game split-files.
	Checksum is generated from game title, multibyte character string,
	excluding 0-padding bytes. It is undetermined whenever it's 8 or 7 bit.
	Eg. final file name may endup being "ul.B800486C.SLUS_206.31.00".
	This appears to be method used first by USB Advance.
	File splitting size: 1073741824 B.

	Original CRC32-Function from OPL-Sourcecode.
	Original function name: "USBA_crc32()"
	Source file path: "./OPL-Daily-Builds-source_20200627.zip/src/system.c"

	Also implemented in libopl python library as "usba_crc32()"
	function in  "libopl/common.py" file.
*/
uint32_t fu_GetUsbAdvanceULCrc32( const char* string2 )
{
	int32_t crc, table, count, byte;
	static uint32_t crctab[0x400];
	for (table = 0; table < 256; table++) {
		crc = table << 24;
		for (count = 8; count > 0; count--) {
			if (crc < 0)
				crc = crc << 1;
			else
				crc = (crc << 1) ^ 0x04C11DB7;
		}
		crctab[255 - table] = crc;
	}
	do {
		byte = string2[count++];
		crc = crctab[byte ^ ((crc >> 24) & 0xFF)] ^ ((crc << 8) & 0xFFFFFF00);
	} while (string2[count - 1] != 0);
	return crc;
}

/*
	ul_cfg_dir_sample.txt
	-------------------------
	ul.405E38DD.SLUS_209.46.00   1073741824  1
	ul.405E38DD.SLUS_209.46.01   1073741824  1
	ul.405E38DD.SLUS_209.46.02   1073741824  1
	ul.405E38DD.SLUS_209.46.03   1073741824  1
	ul.405E38DD.SLUS_209.46.04   205127680   1
	ul.51EDB881.SCUS_973.28.00   1073741824  1
	ul.51EDB881.SCUS_973.28.01   1073741824  1
	ul.51EDB881.SCUS_973.28.02   1073741824  1
	ul.51EDB881.SCUS_973.28.03   1073741824  1
	ul.51EDB881.SCUS_973.28.04   1019510784  1
	ul.cfg                       128         1
//*/

std::vector<std::string>
fu_GetInstalledGameFilesD2( std::string srDirname, std::string srTitle, std::string srGameIdWthDot )
{
	assert( srGameIdWthDot.size() == 11 );
	std::vector<std::string> outp;
	uint32_t uCrc = fu_GetUsbAdvanceULCrc32( srTitle.c_str() );
	std::string srFnamePattern;
	srFnamePattern = HfArgs("ul.%1.%2")
			.arg_u64( uCrc, 16, 8, '0', 0, 0 )
			.arg(srGameIdWthDot.c_str()).c_str();
	auto fs2 = fu_GetDiskDirContentsD2( srDirname, FU_DCFilesOnly|FU_DCAbsPaths );
	for( auto a = fs2.begin(); a != fs2.end(); ++a ){
		assert( !a->empty() );
		std::string fname = *(a->begin());
		assert( !fname.empty() );
		auto parts2 = hf_basename3<char>( fname.c_str(), 0, 8 );
		auto bn2  = parts2.first;
		auto ext2 = parts2.second;
		bool mtch;
		mtch = (ext2[0] == '0' || strtoul( ext2.c_str(), 0, 10 ));
		mtch = ( mtch ? ( !hf_strcasecmp<char>( bn2.c_str(), srFnamePattern.c_str(), -1 ) ) : 0 );
		if( mtch ){
			outp.push_back( fname );
		}
	}
	return outp;
}
bool FU_CmdUlDelete::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened [mJ8p8E]\n");
		return 0;
	}
	std::vector<uint32_t> indices2; bool bDryRun = 0;
	for( const auto& a : CmdArgs.aArgs ){
		if( !a.empty() && a[0] == '*' ){
			uint32_t idx = static_cast<uint32_t>(
					strtoul( a.substr(1,std::string::npos).c_str(), 0, 10 ) );
			if( idx >= 1 )
				indices2.push_back( idx - 1 );
		}else if( a == "-t" ){
			bDryRun = 1;
		}
	}
	if( indices2.empty() ){
		printf("ERROR: No game numbers on the command line specified [iv2I3jI]\n");
		return 0;
	}
	std::string srUlCfg = FU_OpenedDisk->getCDPathTo("ul.cfg");
	FRESULT rs2;
	std::string err2;
	std::vector<FU_UlCfgEn> entries3;
	if( FR_OK != (rs2 = fu_ParseUlCfgFileD2( srUlCfg.c_str(), &entries3, &err2 )) ){
		printf("ERROR: %s. Code:%d [Zyi7xPJ]\n", err2.c_str(), rs2 );
		return 0;
	}
	std::vector<std::string> deletions2;
	std::vector<FU_UlCfgEn> entries4;
	uint32_t ii2 = 0;
	for( auto a = entries3.begin(); a != entries3.end(); ++a, ii2++ ){
		auto b = std::find( indices2.begin(), indices2.end(), ii2 );
		if( b != indices2.end() ){
			printf("NOTE: removing *%d [%s]\n", int(ii2+1), a->srTitle2.c_str() );
			assert( a->srIdStr.size() == 11 );
			std::string dir2 = hf_dirname( srUlCfg.c_str() );
			auto fs2 = fu_GetInstalledGameFilesD2( dir2, a->srTitle2, a->srIdStr );
			if( !fs2.empty() ){
				if( bDryRun ){
					printf("Game files:\n");
					for( auto a = fs2.begin(); a != fs2.end(); ++a ){
						assert( !a->empty() );
						printf("  [%s]\n", hf_basename2( a->c_str(), 0 ).c_str() );
					}
				}
				for( auto a = fs2.begin(); a != fs2.end(); ++a ){
					assert( !a->empty() );
					deletions2.push_back( *a );
				}
			}
		}else{
			entries4.push_back( *a );
		}
	}
	if( !bDryRun ){
		for( auto a = deletions2.begin(); a != deletions2.end(); ++a ){
			if( FR_OK != FU_CmdDelete::deleteFile( *a, 1 ) ){
				printf("ERROR: Failed deleting disk file [cLrixQB]\n");
				printf("       [%s]\n", hf_basename2( a->c_str(), 0 ).c_str() );
			}
		}
		{
			auto data2 = fu_CreateUlCfgFileData( entries4 );
			rs2 = fu_PutDiskFileContents( srUlCfg.c_str(), FA_WRITE|FA_CREATE_ALWAYS, &data2[0], data2.size() );
			if( rs2 != FR_OK ){
				printf("ERROR: Failed writing ul.cfg file. Code:%d [qjD2H6q]\n", rs2 );
				return 0;
			}
		}
	}
	return 1;
}

