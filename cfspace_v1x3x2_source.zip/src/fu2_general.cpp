#include "fu2_general.h"
#include <memory>
#include "diskio.h"		// //FatFs Declarations of disk functions
#include "fu2_ulcfg.h"
#include <cctype>       //std::isalpha()

static_assert( sizeof(WCHAR)==2, "" );
static_assert( sizeof(TCHAR)==1, "" );

FU_Disk*      FU_OpenedDisk = nullptr;
FU_AppParams* FU_Params2    = nullptr;

const std::vector<FU_SCmdDfn> FU_CmdDefinitions = {
	{ {"open",},
			[](){return "Opens FAT32 disk, partition or disk image.\n"
						"Use -r switch to open in the read-only mode.";},
			[](){ return new FU_CmdOpen;}, 0, 0, },
	{ {"close",},
			[](){return "Closes current, previously opened disk.";},
			[](){ return new FU_CmdClose;}, 0, 0, },
	{ {"ls","dir",},
			[](){return "Shows contents of current directory.\n"
						"Use '-l' switch to get long listing.\n"
						"Use '-f' switch to show fragmentation for each file.";},
			[](){ return new FU_CmdLs; }, 0, 0, },
	{ {"cd",}, [](){return "Changes current directory.\n"
							"Use 'cd ..' to switch to the parent directory.\n"
							"Use 'cd /' to switch to the root directory.";},
			[](){ return new FU_CmdCd; }, 0, 0, },
	{ {"pwd",}, [](){return "Shows current directory path.";},
			[](){return new FU_CmdPwd;}, 0, 0, },
	{ {"diskinfo","dinf",},
			[](){return "Shows basic disk information.\n"
						"Size, empty space, label, etc.";},
			[](){ return new FU_CmdDiskinfo;}, 0, 0, },
	{ {"exit","quit","q",}, [](){return "Exits the program and returns to the shell.";},
			[](){return new FU_CmdExit;}, 0, 0, },
	{ {"dele",}, [](){return"Deletes single file or empty-directory.\n"
							"Will not delete files with read-only flag\n"
							"or non-empty directories.\n"
							"Use '-f' switch to force delete of read-only file.";},
			[](){return new FU_CmdDelete;}, 0, 0, },
	{ {"mkfile","mkf",},
			[](){return "Creates new file. Empty or with prealocated size.\n"
						"File is created contiguous, with contents undefined.\n"
						"Use '-s SIZE' switch to specify its size.\n"
						"Fails if there is not enough contiguous space available.";},
			[](){return new FU_CmdMkfile;}, 0, 0, },
	{ {"extr",}, [](){return"Copies file from curently mounted disk to the system.\n"
							"Syntax: extr <source> <dest>.\n";},
			[](){return new FU_CmdExtract;}, 0, 0, },
	{ {"inj",}, [](){return "Copies file from the system to the currently opened disk.\n"
							"By default, new file is being created contiguous.\n"
							"Fails if there is not enouh contiguous space on the disk.\n"
							"Use '-o' switch to allow file to be created non-contiguous.\n"
							"Syntax: inj [-o] <source> [<dest>]\n"
							"If <dest> is omited, new file name is automatically taken from the path in <source>.\n"
							"If the file name in <dest> is without the path part, creates file in the current directory.";},
			[](){return new FU_CmdInject;}, 0, 0, },
	{ {"showfrag","sfr",},
			[](){return "Shows the file fragmentation.\n"
						"Syntax: showfrag <file-name>\n"
						"This command is limited in that it can only tell if the file is fragmented or not.\n"
						"If retrieved value is 1 then the file is not fragmented, contiguous.\n"
						"If the file is fragmented, the value shown is '2+'.\n"
						"Note: you can also use the 'ls -f' command.";},
			[](){return new FU_CmdShowFr;}, 0, 0, },
	{ {"scr","s",},
			[](){return "Runs commands from the text script - file on the system.\n"
						"Syntax: scr [-c] <file-name>\n"
						"File name is expected to be an ANSI or UTF-8 text file.\n"
						"Use '-c' switch to continue executing on errors.\n"
						"This command can be used to automate tasks from the actual shell.\n"
						"For shell automation, consider command line switches: '--run_cmd'\n"
						"and '--error_exit'.\n"
						"If file name is without the extension, auto checks for the TXT file.";},
			[](){return new FU_CmdRunScript;}, 0, 0, },
	{ {"show_disks","sd",},
			[](){return "Shows system disks or volumes.\n"
						"Use the 'open' command to open diisk from the list.\n"
						"For example, to open disk D, use 'open D:' command.\n"
						"On unix platforms use device names from the /dev directory.\n"
						"Example: 'open /dev/sdc1'.";},
			[](){ return new FU_CmdShowDisks;}, 0, 0, },
	{ {"ul_inject","uli",},
			[](){return "Injects ISO adding entry to the 'ul.cfg' file.\n"
						"Asks to press Enter key once files allocated, before file copy.\n"
						"WARNING: does not checks if the same game already exists.\n"
						"For PS2 games on USB disks.\n"
						"This is USB Advance format that is also used by OPL.\n"
						"Use '-b' to do not update the 'ul.cfg' file.\n"
						"Use '-i' to do set game-id manually."
						//"Use '-s SIZE' to set split size (Warning: for debug only)."
						;},
			[](){ return new FU_CmdUlInject;}, 0, 0, },
	{ {"ul_list","ull",},
			[](){return "Lists contents of 'ul.cfg' file in current directory on the disk.\n"
						"Use '-l' switch to show more info (game-id).";},
			[](){ return new FU_CmdUlList;}, 0, 0, },
	{ {"ul_dele","uld",},
			[](){return "Delete entry from 'ul.cfg' file in current directory on the disk.\n"
						"Specify one or more entries as asterissk with number, 1-based.\n"
						"Eg. 'ul_dele *2' or 'ul_dele *1 *5 *10'\n"
						"Use '-t' switch for test mode - don't delete or modify any files.";},
			[](){ return new FU_CmdUlDelete;}, 0, 0, },
};

std::string fu_GetHelpForCommand( const char* szCmdName, bool bInclAliases )
{
	for( const FU_SCmdDfn& cm2 : FU_CmdDefinitions ){
		auto a = std::find( cm2.names2.begin(), cm2.names2.end(), szCmdName );
		if( a != cm2.names2.end() ){
			std::string res;
			if( bInclAliases && cm2.names2.size() > 1 ){
				res += (cm2.names2.size() <= 2 ? "Alias: " : "Aliases: ");
				for( auto a = cm2.names2.begin(); a != cm2.names2.end(); ++a ){
					if( *a != szCmdName )
						res += (*a + ", ");
				}
				res = (hf_rtrim_stdstring( res.c_str(), ", " ) + "\n");
			}
			res += cm2.fnGetCommandHelp();
			return res;
		}
	}
	return "";
}
bool fu_CmdParamsToObject( const FU_CmdArgs& cargs, std::string* err4, FU_CmdBase** outp )
{
	std::string err3, *err2 = ( err4 ? err4 : &err3 );
	*outp = nullptr;
	for( const FU_SCmdDfn& cm2 : FU_CmdDefinitions ){
		std::vector<std::string>::const_iterator b;
		b = std::find( cm2.names2.begin(), cm2.names2.end(), cargs.name2 );
		if( b != cm2.names2.end() ){
			if( !cm2.fnCreateCommand ){
				*err2 = "Command not implemented [HaiYpxjp]";
				return 0;
			}else{
				*outp = cm2.fnCreateCommand();
				assert( *outp );
				(**outp).setCmdArgs( cargs );
				break;
			}
		}
	}
	if( !*outp ){
		*err2 = HfArgs("Command not recognized '%1' [qIkGxx]").arg(cargs.name2.c_str()).c_str();
		return 0;
	}
	return 1;
}

bool fu_EnterCmdLoop()
{
	char bfr[1024]; bool bSuccess = 1;
	for( int ii3=0; bSuccess; ii3++ ){
		std::string srCmd;
		if( !ii3 ){
			printf("\n");
			printf(">>>    Welcome to the CFSpace micro shell   <<<\n");
			printf(">>> Enter 'help' or 'list' to get more info <<<\n");
			printf(">>>                                         <<<\n");
			printf(">>>   WARNING: USE AT YOUR OWN RISK!        <<<\n");
			printf(">>>            NO WARRANTY PROVIDED!        <<<\n");
			printf(">>>            BACKUP YOUR DATA FIRST!      <<<\n");
			printf("\n");
			srCmd = FU_Params2->srRunCmd;
		}
		if( srCmd.empty() ){
			printf("$:: ");
			if( !std::fgets( bfr, sizeof(bfr), stdin ) ){
				printf("ERROR: fgets() failed [XzYYTPt]\n");
			}
			srCmd = hf_rtrim_stdstring( bfr, "\r\n\x20");
		}
		if( srCmd.empty() ){
			continue;
		}
		FU_CmdArgs cargs = fu_ParseCmdString( srCmd.c_str() );
		if(0){
		}else if( cargs.name2 == "help" || cargs.name2 == "h" ){
			if( cargs.aArgs.empty() ){
				printf("Use 'list' to get the list of all commands and their aliases.\n");
				printf("To get more info on the particular command enter 'help <command>'.\n");
				printf("Enter 'exit' to quit the program.\n");
				printf("NOTE: always use forward slash as the directory separator ('/').\n");
			}else if( !cargs.aArgs.empty() && cargs.aArgs[0] == "all" ){
				printf("\n");
				for( const FU_SCmdDfn& cm2 : FU_CmdDefinitions ){
					printf(">>> %s <<<\n", cm2.names2[0].c_str() );
					printf("%s\n\n", fu_GetHelpForCommand( cm2.names2[0].c_str(), 1 ).c_str() );
				}
			}else{
				std::string srHelp, cmdnm = cargs.aArgs[0];
				srHelp = fu_GetHelpForCommand( cmdnm.c_str(), 1 );
				if( !srHelp.empty() ){
					printf("\n");
					printf(">>> %s <<<\n", cmdnm.c_str() );
					printf("%s\n", srHelp.c_str() );
				}else{
					printf("ERROR: No help available for '%s' command.\n", cmdnm.c_str() );
				}
			}
		}else if( cargs.name2 == "list" ){
			printf("Listing available commands and aliases:\n");
			for( const FU_SCmdDfn& cm2 : FU_CmdDefinitions ){
				assert( !cm2.names2.empty() );
				for( const auto& a : cm2.names2 ){
					printf("%s%s\n", "\x20\x20\x20\x20", a.c_str() );
				}
			}
		}else{
			std::string err2;
			FU_CmdBase* lpCmd = nullptr;
			if( fu_CmdParamsToObject( cargs, &err2, &lpCmd ) ){
				assert( lpCmd );
				if( lpCmd->isExitCommand() ){
					break;
				}
				if( !lpCmd->exec2() && FU_Params2->bExitOnCmdError ){
					printf("INFO: Exit on first error is in effect.\n");
					bSuccess = 0;
				}
				delete lpCmd;
			}else{
				printf("ERROR: %s [gZOwJF]\n", err2.c_str() );
			}
		}
	}
	return bSuccess;
}

bool FU_CmdLs::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: There is no disk opened.\n");
		return 0;
	}
	bool bLongListing = 0, bShowFrgm = 0;
	for( const auto& a : CmdArgs.aArgs ){
		if( a == "-l" ){
			bLongListing = 1;
		}else if( a == "-f" ){
			bShowFrgm = 1;
			bLongListing = 1;
		//}else if( a == "-R" ){
		//	//bRecursive = 1;
		}
	}
	printf("Directory contents:\n");
	std::vector<std::vector<std::string> > lines2;
	{
		std::string srCd = HfArgs("%1:%2")
			.arg( FU_OpenedDisk->uFsIdent )
			.arg( FU_OpenedDisk->srCurrentDir.c_str() ).c_str();

		lines2 = fu_GetDiskDirContentsD2( srCd,
				(FU_DCDirSlMark | (bShowFrgm ? FU_DCShowFragm : 0)) );
	}
	if( lines2.empty() ){
		printf("\x20\x20<empty>\n");
	}else{
		{
			using arg_t = std::vector<std::string>;
			std::sort( lines2.begin(), lines2.end(),
					[]( arg_t a, arg_t b )->bool{
						assert( !a.empty() && !b.empty() );
						return (hf_strcasecmp( a[0].c_str(), b[0].c_str() ) < 0);
					});
		}
		if( bLongListing ){
			std::vector<size_t> extents2;
			extents2.resize( ( lines2.empty() ? 4 : lines2[0].size() ), 0 );
			for( const auto& ln3 : lines2 ){ // for each line.
				size_t ii2 = 0;
				for( auto a = ln3.begin(); a != ln3.end(); ++a, ++ii2 ){ // for reach word in the line.
					assert( ii2 < extents2.size() );
					extents2[ii2] = std::max<size_t>( a->size(), extents2[ii2] );
					extents2[ii2] = std::min<size_t>( FU_MaxFnameListingLen, extents2[ii2] );
				}
			}
			for( const auto& ln3 : lines2 ){
				size_t ii2 = 0;
				for( auto a = ln3.begin(); a != ln3.end(); ++a, ++ii2 ){
					bool bFirstCol = !ii2;
					bool bLastCol  = (ii2+1 == ln3.size());
					std::string sr2 = *a;
					if( sr2.size() < extents2[ii2] ){
						sr2.resize( extents2[ii2], '\x20' );
					}
					auto sr3 = hf_rtrim_stdstring( sr2.c_str(), "\x20\t" );
					if( sr3.size() > FU_MaxFnameListingLen ){
						sr2.resize( FU_MaxFnameListingLen - 3 );
						sr2 += "...";
					}
					printf("%s%s%s",
							( bFirstCol ? "\x20\x20" : ""),
							sr2.c_str(),
							( bLastCol ? "" : "\x20\x20") );
				}
				printf("\n");
			}
		}else{  // Else listing shows only file names. Also no truncating.
			for( const auto& ln3 : lines2 ){
				assert( !ln3.empty() );
				printf("\x20\x20%s\n", ln3[0].c_str() );
			}
		}
	}
	return 1;
}

bool FU_CmdOpen::exec2()
{
	std::string srDiskName;
	bool bReadOnly2 = FU_Params2->bOpenReadOnly;
	for( const auto& a : CmdArgs.aArgs ){  //FU_CmdArgs
		if( !a.empty() ){
			if( a[0] != '-' ){
				if( srDiskName.empty() ){
					srDiskName = a.c_str();
				}
			}else if( a == "-r" ){
				bReadOnly2 = 1;
			}
		}
	}
	if( FU_OpenedDisk ){
		printf("ERROR: Another disk is already opened.\n");
		printf("       Opened disk needs to be closed first.\n");
		return 0;
	}
	if( srDiskName.empty() ){
		printf("ERROR: No disk to open.\n");
		printf("       No disk name at the command line.\n");
		return 0;
	}
	if( isPathSystemDisk( srDiskName.c_str() ) ){
		srDiskName = convShortDiskPathToSystem( srDiskName );
		printf("INFO: using system path: [%s]\n", srDiskName.c_str() );
	}else{
		if( !hf_FileExists( srDiskName.c_str() ) ){
			printf("ERROR: File not found.\n");
			printf("       Path: [%s]\n", srDiskName.c_str() );
			return 0;
		}
	}
	if( bReadOnly2 ){
		printf("INFO: opening in read-only mode.\n");
	}
	FU_Disk dsk; std::string err5;
#	ifdef FU2_WINXX
		// Note: flag FILE_SHARE_WRITE is causing no write access to the disk.
		//       Function WriteFile() keeps returning "Access Denied".
		dsk.handle2 = CreateFile( srDiskName.c_str(),
				GENERIC_READ | ( bReadOnly2 ? 0 : GENERIC_WRITE ),
				FILE_SHARE_READ,
				0, OPEN_EXISTING,
				FILE_FLAG_NO_BUFFERING,
				0 );
		dsk.handle2 = ( dsk.handle2 != INVALID_HANDLE_VALUE ? dsk.handle2 : nullptr );
		//fu_WinapiGetLastError
		err5 = (dsk.handle2 ? err5 : fu_WinapiGetLastError());
#	else
		dsk.srModeStr = ( bReadOnly2 ? "rb" : "r+b");
		dsk.fph2 = std::fopen( srDiskName.c_str(), dsk.srModeStr.c_str() );
		err5 = (dsk.fph2 ? err5 : std::strerror(errno));
#	endif
	if( !dsk.fph2 && !dsk.handle2 ){
		printf("ERROR: Could not open the disk. [Ayx76MJ]\n");
		printf("       [%s]\n", err5.c_str() );
		return 0;
	}
	dsk.uFileSize   = hf_GetFileSize64( dsk.fph2 );
	dsk.srDiskFname = srDiskName;
	dsk.bValid      = 1;
	{
		uint32_t nSectorSize2 = 0;
		bool rs4 = fu_GetDeviceSectorSize( dsk.fph2, srDiskName.c_str(), &nSectorSize2 );
		if( rs4 && nSectorSize2 ){
			dsk.uSectorSize = nSectorSize2;
		}else{
			dsk.uSectorSize = FU_CommonSectorSize;
		}
	}
	assert( FU_OpenedDisk == nullptr );
	FU_OpenedDisk = new FU_Disk( dsk );  // valid pointer needed durning f_mount() call below.
	//
	dsk.lpFatFs = reinterpret_cast<FATFS*>( malloc( sizeof(FATFS) ) );
	FRESULT rs2 = f_mount( dsk.lpFatFs, "0:/", 1 );
	if( rs2 ){
		printf("ERROR: Mounting failed, FRESULT:%d [6LRugp3]\n", (int)rs2 );
		assert( FU_OpenedDisk );
		FU_Disk::clear3( &FU_OpenedDisk );
		return 0;
	}
	printf("INFO: Disk opened successfully.\n");
	return 1;
}

bool FU_CmdOpen::isPathSystemDisk( std::string inp ) // static
{
#	ifdef FU2_WINXX
		if( inp.size() >= 2 && inp.substr( 0, 2 ) == "\\\\" ){
			return 1;
		}
		if( inp.size() == 2 && std::isalpha(inp[0]) && inp[1] == ':' ){
			return 1;
		}
		if( inp.size() == 3 && std::isalpha(inp[0]) && inp[1] == ':' && strchr("/\\", inp[2] ) ){
			return 1;
		}
#	endif
	return 0;
}

std::string FU_CmdOpen::convShortDiskPathToSystem( std::string inp ) // static
{
#	ifdef FU2_WINXX
		if( inp.size() >= 2 && inp.substr(0,2) == "\\\\" ){
			return inp;
		}
		std::string sr2;
		if( inp.size() == 2 && std::isalpha(inp[0]) && inp[1] == ':' ){
			sr2 = inp;
		}
		if( inp.size() == 3 && std::isalpha(inp[0]) && inp[1] == ':' && strchr("/\\", inp[2] ) ){
			sr2 = inp.substr(0,2);
		}
		if( !sr2.empty() ){
			return ( std::string("\\\\.\\") + sr2 );
		}
#	endif
	return inp;
}
void FU_CmdOpen::
openDiskOnStartup( const char* szDiskName, bool bReadOnly3, const char* szCdir )
{
	std::string sr2 = HfArgs("open %1\x22%2\x22")
			.arg( bReadOnly3 ? "-r " : "" )
			.arg( szDiskName ).c_str();
	FU_CmdOpen cmdopen;
	cmdopen.setCmdArgs( fu_ParseCmdString( sr2.c_str() ) );
	bool rs2 = cmdopen.exec2();
	if( rs2 && szCdir && *szCdir ){
		std::string sr3 = HfArgs("cd \x22%1\x22").arg( szCdir ).c_str();
		FU_CmdCd cmdcd;
		cmdcd.setCmdArgs( fu_ParseCmdString( sr3.c_str() ) );
		cmdcd.exec2();
	}
}

void FU_Disk::clear2()
{
	if( fph2 ){
		std::fclose( fph2 );
		fph2 = 0;
	}
#	ifdef FU2_WINXX
		if( handle2 ){
			CloseHandle( handle2 );
			handle2 = 0;
		}
#	endif
	if( lpFatFs ){
		free( lpFatFs );
		lpFatFs = 0;
	}
	*this = FU_Disk();
}
/// Convinient clearing of the object pointer with call to clear2() as well.
/// Ment to be used on error or on dis-mount.
void FU_Disk::clear3( FU_Disk** dsk4 ) //static
{
	assert( dsk4 );
	assert( *dsk4 );
	(**dsk4).clear2();
	delete *dsk4;
	*dsk4 = nullptr;
}

bool FU_CmdClose::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened. Nothing to close.\n");
		return 0;
	}
	FRESULT rs3 = f_mount( nullptr, "0:/", 0 );   // un-mount.
	if( rs3 ){
		printf("ERROR: Un-mount failed. FRESULT:%d [K0GPVueYq]\n", (int)rs3 );
		return 0;
	}
	FU_Disk::clear3( &FU_OpenedDisk );
	return 1;
}
bool FU_CmdPwd::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened. No current directory.\n");
		return 0;
	}
	auto srCd = FU_OpenedDisk->srCurrentDir;
	srCd = ( srCd.empty() ? std::string("/") : srCd );
	printf("%s\n", srCd.c_str() );
	return 1;
}
bool FU_CmdCd::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened. Cannot change current directory.\n");
		return 0;
	}
	std::string srDir;
	for( const auto& a : CmdArgs.aArgs ){  //FU_CmdArgs
		if( !a.empty() && srDir.empty() ){
			srDir = a;
		}
	}
	if( srDir.empty() ){
		printf("ERROR: No directory specified.\n");
		return 0;
	}
	FU_Disk* dsk2 = FU_OpenedDisk;

	std::string srCdNew; bool bChangeToRoot = 0;
	if( srDir == "/" ){
		srCdNew = "";  //dsk2.srCurrentDir = "";
		bChangeToRoot = 1;
	}else if( srDir == ".." ){
		if( !dsk2->srCurrentDir.empty() ){
			srCdNew = hf_dirname( (std::string("/")+dsk2->srCurrentDir).c_str() );
			srCdNew = hf_trim_stdstring<char>( srCdNew.c_str(), "/");
			bChangeToRoot = ( srCdNew.empty() ? 1 : 0 );
			//printf("[SW20qYX84ZBa]\n");
			//printf("srCdNew: [%s]\n", srCdNew.c_str() );
		}
	}else if( !srDir.empty() ){
		if( hf_strBeginsWith( srDir.c_str(), -1, "./", -1, 0 ) ){
			srDir = srDir.substr( 2, std::string::npos );
		}
		srDir = hf_trim_stdstring<char>( srDir.c_str(), "/" );
		if( !srDir.empty() ){
			srCdNew = dsk2->getCDPathTo( srDir );
		}
	}
	if( !srCdNew.empty() || bChangeToRoot ){
		printf("INFO: changing dir to [%s]\n", srCdNew.c_str() );
		FRESULT rs2;
		DIR dr2;
		if( FR_OK == (rs2 = f_opendir( &dr2, srCdNew.c_str() ) ) ){
			f_closedir( &dr2 );
			dsk2->srCurrentDir = srCdNew;
		}else{
			printf("ERROR: Current directory change failed.\n");
			printf("       Path: [%s]\n", srCdNew.c_str() );
			return 0;
		}
	}
	return 1;
}
bool FU_CmdDiskinfo::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened. No information to show.\n");
		return 0;
	}
	char bfr2[128] = ""; DWORD uVolSN = 0;
	f_getlabel("", bfr2, &uVolSN );

	FATFS *fs3;
	DWORD fre_clust;   //DWORD fre_clust, fre_sect, tot_sect;
	uint64_t fre_sect, tot_sect;
	// Get volume information and free clusters of drive
	uint64_t uDSize = 0, uDFree = 0;
	FRESULT res = f_getfree("", &fre_clust, &fs3 );
	if( !res ){
		// Get total sectors and free sectors
		tot_sect = uint64_t(fs3->n_fatent - 2) * fs3->csize;
		fre_sect = uint64_t(fre_clust) * fs3->csize;
		//fs3->ssize //sector size
		uDSize = (tot_sect * fs3->ssize);
		uDFree = (fre_sect * fs3->ssize);
	}
	printf("Disk information:\n");
	printf("  Volume label : [%s]\n", bfr2 );
	printf("  Volume S/N   : [0x%08X]\n", uVolSN );
	printf("  Size         : %s B (%s KiB)\n", HfArgs("%1").arg( uDSize ).c_str(), HfArgs("%1").arg( uDSize / 1024 ).c_str() );
	printf("  Free space   : %s B (%s KiB)\n", HfArgs("%1").arg( uDFree ).c_str(), HfArgs("%1").arg( uDFree / 1024 ).c_str() );
	printf("  Disk path    : [%s]\n", FU_OpenedDisk->srDiskFname.c_str() );
	printf("  Sector size  : %u\n", FU_OpenedDisk->uSectorSize );
	return 1;
}

/// Command line parse with quotation and simple-escapes.
/// \sa hf_parseCmdString()
FU_CmdArgs fu_ParseCmdString( const char* inp )
{
	FU_CmdArgs outp;
	std::vector<std::string> args2;
	args2 = hf_parseCmdString( inp );
	if( !args2.empty() ){
		outp.name2 = args2[0];
		args2.erase( args2.begin() );
	}
	outp.aArgs = args2;
	return outp;
}
bool FU_CmdExtract::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened.\n");
		return 0;
	}
	std::string srSrc, srDst;
	auto endd = CmdArgs.aArgs.end();
	auto a = CmdArgs.aArgs.begin();
	for(; a != endd; ++a ){
		if( !hf_strBeginsWith( a->c_str(), -1, "-", -1, 0 ) ){
			if( srSrc.empty() ){
				srSrc = *a;
			}else if( srDst.empty() ){
				srDst = *a;
			}
		}
	}
	if( srSrc.empty() ){
		printf("ERROR: no source file name specified.\n");
		return 0;
	}else if( srDst.empty() ){
		printf("ERROR: no destination file name specified.\n");
		return 0;
	}
	srSrc = FU_OpenedDisk->getCDPathTo( srSrc );
	printf("INFO: Extracting file, from-to:\n");
	printf("      [%s]\n", srSrc.c_str() );
	printf("      [%s]\n", srDst.c_str() );
	uint8_t* bfrRw = nullptr;
	FILE* fp3 = nullptr;
	std::pair<bool,FIL> fi2( 0, FIL() );
	FRESULT rs2;
	std::shared_ptr<void> raii3( 0, [&](void*){
		if( fi2.first ){
			f_close( &fi2.second );
			fi2.first = 0;
		}
		if( fp3 ){
			fclose(fp3);
			fp3 = nullptr;
		}
		if(bfrRw){
			free(bfrRw);
			bfrRw = nullptr;
		}
	});
	rs2 = f_open( &fi2.second, srSrc.c_str(), FA_READ|FA_OPEN_EXISTING );
	if( rs2 != FR_OK ){
		printf("ERROR: Failed opening existing disk file.\n");
		printf("       [%s]\n", srSrc.c_str() );
		return 0;
	}
	fi2.first = 1;
	FSIZE_t nReadd = 0, uFsize;
	uFsize = f_size( &fi2.second );
	//
	fp3 = std::fopen( srDst.c_str(), "wb" );
	if( !fp3 ){
		std::string err = std::strerror(errno);
		printf("ERROR: Failed opening local filesystem file for write.\n");
		printf("       [%s]\n", err.c_str() );
		printf("       [%s]\n", srDst.c_str() );
		return 0;
	}
	bfrRw = (uint8_t*)malloc( FU_Params2->uBuffRWSize );
	UINT br2;
	for(;;){
		f_read( &fi2.second, bfrRw, FU_Params2->uBuffRWSize, &br2 );
		if( !br2 ) break;
		//printf("Readd %u bytes.\n", br2 );
		hf_Seek64( fp3, nReadd );
		size_t nWrtn = std::fwrite( bfrRw, 1, br2, fp3 );
		if( nWrtn != br2 ){
			printf("ERROR: File write failed. Requested %u, wtitten %u\n", br2, (unsigned int)nWrtn );
			return 0;
		}
		nReadd += br2;
		{
			double perc = (double(nReadd) / uFsize);
			printf("\r%.2f%%", (float(perc) * 100.f) );
			fflush( stdout );  //usleep( 300000 );
		}
	}
	printf("\n"); //perc
	return 1;
}
bool FU_CmdMkfile::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened.\n");
		return 0;
	}
	FSIZE_t uRqFsize = 0;
	std::string srFnm;
	auto endd = CmdArgs.aArgs.end();
	for( auto a = CmdArgs.aArgs.begin(); a != endd; ++a ){
		auto b = a; ++b;
		if( !hf_strBeginsWith( a->c_str(), -1, "-", -1, 0 ) ){
			if( srFnm.empty() ){
				srFnm = *a;
			}
		}else if( *a == "-s" && b != endd && !uRqFsize ){
			uRqFsize = std::strtoul( b->c_str(), 0, 10 );
			a = b;
		}
	}
	if( srFnm.empty() ){
		printf("ERROR: No file name to create specified.\n");
		return 0;
	}
	srFnm = FU_OpenedDisk->getCDPathTo( srFnm );
	bool rs2 = createAllocFile( srFnm.c_str(), uRqFsize, nullptr, 0 );
	return rs2;
}
bool FU_CmdDelete::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened.\n");
		return 0;
	}
	std::string srFnm2; bool bClearROFlag = 0;
	auto endd = CmdArgs.aArgs.end();
	for( auto a = CmdArgs.aArgs.begin(); a != endd; ++a ){
		auto b = a; ++b;
		if( !hf_strBeginsWith( a->c_str(), -1, "-", -1, 0 ) ){
			if( srFnm2.empty() ){
				srFnm2 = *a;
			}
		}else if( *a == "-f" ){
			bClearROFlag = 1;
		}
	}
	if( srFnm2.empty() ){
		printf("ERROR: No file name to delete specified.\n");
		return 0;
	}
	srFnm2 = FU_OpenedDisk->getCDPathTo( srFnm2 );
	FRESULT rs2;
	if( FR_OK != (rs2 = deleteFile( srFnm2.c_str(), bClearROFlag )) ){
		printf("ERROR: Failed removing disk file. Code:%d\n", rs2 );
		printf("       [%s]\n", srFnm2.c_str() );
		if( rs2 == FR_WRITE_PROTECTED ){
			printf("File is write protected. Use -f switch to force delete.\n");
		}
		return 0;
	}
	return 1;
}
FRESULT FU_CmdDelete::deleteFile( std::string srFname2, bool bClearROFlag2 )
{
	FRESULT rs2;
	if( bClearROFlag2 ){
		if( FR_OK != (rs2 = f_chmod( srFname2.c_str(), 0, AM_RDO ))){ //clears the read-only attribute.
			printf("WARN: Failed clearing the read-only attribute. Code:%d\n", rs2 );
			return rs2;
		}
	}
	if( FR_OK != (rs2 = f_unlink( srFname2.c_str() )) ){
		printf("WARN: File delete failed. Code:%d\n", rs2 );
		return rs2;
	}
	return FR_OK;
}

/// Creates and allocates file on the disk given file size in bytes.
/// NOTE: It appears that if the file is not closed before the disk is,
///       created file ends up zero size. this may happen if
///       using 'ouOpenedFile' optional parameter.
bool FU_CmdMkfile::
createAllocFile( const char* fpathname, FSIZE_t uRqFsize2,
			FIL* ouOpenedFile, bool bQuiet2 ) //static
{
	std::string srFnm3( fpathname );
	std::pair<bool,FIL> fi2( 0, FIL() );
	FRESULT rs2;
	std::shared_ptr<void> raii4( 0, [&](void*){
		if(fi2.first){
			if( ouOpenedFile ){
				*ouOpenedFile = fi2.second;
			}else{
				f_close( &fi2.second );
				fi2.first = 0;
			}
		}
	});
	rs2 = f_open( &fi2.second, srFnm3.c_str(), FA_WRITE|FA_CREATE_NEW );
	if( rs2 != FR_OK ){
		printf("ERROR: Failed creating disk file. Code:%d [8cP3IPh]\n", rs2 );
		printf("       [%s]\n", srFnm3.c_str() );
		return 0;
	}
	fi2.first = 1;
	if( !uRqFsize2 )
		return 1;
	if(!bQuiet2){
		printf("INFO: Allocating %u bytes of contiguous file space.\n", uRqFsize2 );
	}
	rs2 = f_expand( &fi2.second, uRqFsize2, 1 );
	if( rs2 != FR_OK ){
		printf("ERROR: Failed to allocate %u bytes of contiguous space. Code:%d\n", uRqFsize2, rs2 );
		printf("       [%s]\n", srFnm3.c_str() );
		if( fi2.first ){
			f_close( &fi2.second );
			fi2.first = 0;
		}
		FU_CmdDelete::deleteFile( srFnm3.c_str(), 0 );
		return 0;
	}
	return 1;
}

/// Checks if file is contiguous.
/// Source taken from: "app5.c" - test_contiguous_file()
/// sFileOr - [I/O] File to be checked.
/// bCont   - [OUT] 1:Contiguous, 0:Fragmented
FRESULT fu_TestContiguousFile( FU_SFileOr sFileOr, bool* bCont )
{
	FIL* fpi = 0;
	FRESULT rs2;
	std::pair<bool,FIL> fi2( 0, FIL() );
	std::shared_ptr<void> raii2( 0, [&](void*){
		if( fi2.first ){
			f_close( &fi2.second );
			fi2.first = 0;
		}
	});
	if( !sFileOr.fpi2 ){
		if( FR_OK != (rs2 = f_open( &fi2.second, sFileOr.srFname.c_str(), FA_READ|FA_OPEN_EXISTING )) ){
			return rs2;
		}else{
			fi2.first = 1;
			fpi = &fi2.second;
		}
	}else{
		fpi = sFileOr.fpi2;
	}
    DWORD clst, clsz, step;
    FSIZE_t fsz;
    *bCont = 0;
    rs2 = f_lseek(fpi, 0);            // Validates and prepares the file
    if (rs2 != FR_OK) return rs2;

#	if FF_MAX_SS == FF_MIN_SS
		clsz = (DWORD)fpi->obj.fs->csize * FF_MAX_SS;    // Cluster size
#	else
		clsz = (DWORD)fpi->obj.fs->csize * fpi->obj.fs->ssize;
#	endif
    fsz = f_size(fpi);
    if (fsz > 0) {
        clst = fpi->obj.sclust - 1;  // A cluster leading the first cluster for first test
        while (fsz) {
            step = (fsz >= clsz) ? clsz : (DWORD)fsz;
            rs2 = f_lseek(fpi, f_tell(fpi) + step);    // Advances file pointer a cluster
            if (rs2 != FR_OK) return rs2;
            if (clst + 1 != fpi->clust) break;       // Is not the cluster next to previous one?
            clst = fpi->clust; fsz -= step;          // Get current cluster for next test
        }
        if (fsz == 0) *bCont = 1;    // All done without fail?
    }else{
		*bCont = 1;
    }
    return FR_OK;
}

bool FU_CmdShowFr::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened.\n");
		return 0;
	}
	std::string srFnm4;
	auto endd = CmdArgs.aArgs.end();
	for( auto a = CmdArgs.aArgs.begin(); a != endd; ++a ){
		if( !a->empty() ){
			if( *(a->begin()) != '-' ){
				if( srFnm4.empty() ){
					srFnm4 = *a;
				}
			}
		}
	}
	srFnm4 = FU_OpenedDisk->getCDPathTo( srFnm4 );
	if( srFnm4.empty() ){
		printf("ERROR: No file on the command line.\n");
		return 0;
	}
	FRESULT rs2;
	std::pair<bool,FIL> fi2( 0, FIL() );
	std::shared_ptr<void> raii2( 0, [&](void*){
		if( fi2.first ){
			f_close( &fi2.second );
			fi2.first = 0;
		}
	});
	if( FR_OK != (rs2 = f_open( &fi2.second, srFnm4.c_str(), FA_READ|FA_OPEN_EXISTING )) ){
		printf("ERROR: Failed opening existsing file. Code:%d\n", rs2 );
		printf("       [%s]\n", srFnm4.c_str() );
		return 0;
	}else{
		fi2.first = 1;
	}
	bool bContiguous = 1;
	if( FR_OK != (rs2 = fu_TestContiguousFile( &fi2.second, &bContiguous )) ){
		printf("ERROR: Failed testing for contiguous space. Code:%d [1WxkKjW]\n", rs2 );
		return 0;
	}
	printf("Number of contiguous fragments: %s\n", (bContiguous ? "1": "2+") );
	return 1;
}

bool FU_CmdRunScript::exec2()
{
	std::string srScrFnm; bool bContnOnError = 0;
	auto endd = CmdArgs.aArgs.end();
	for( auto a = CmdArgs.aArgs.begin(); a != endd; ++a ){
		if( *a == "-c" ){
			bContnOnError = 1;
		}else if( srScrFnm.empty() ){
			srScrFnm = *a;
		}
	}
	if( srScrFnm.empty() ){
		printf("ERROR: No script file on the command line.\n");
		return 0;
	}
	if( !hf_FileExists( srScrFnm.c_str() ) ){
		auto bn2 = hf_basename3<char>( srScrFnm.c_str(), 0, 16 );
		srScrFnm = ( bn2.second.empty() ? (srScrFnm + ".txt") : srScrFnm );
		if( !bn2.second.empty() || !hf_FileExists( srScrFnm.c_str() ) ){
			printf("ERROR: Script file not found.\n" );
			printf("       [%s]\n", srScrFnm.c_str() );
			return 0;
		}
	}
	std::vector<std::string> lines3;
	hf_GetFileDSVContents( srScrFnm.c_str(), "\n", lines3, "\r\n\x20\t", HF_EGFC64_KeepNonPrintable|HF_EGFC64_RemoveUtf8BOM );
	lines3.erase( std::remove_if( lines3.begin(), lines3.end(),
			[]( const std::string& a )->bool{
					return a.empty() || a[0] == '#';
			}), lines3.end() );
	auto a = lines3.begin();
	for( int ii2=0; a != lines3.end(); ++a, ii2++ ){
		std::string cmd2 = *a, err;
		FU_CmdBase* lpCmd2 = nullptr;
		FU_CmdArgs cargs2 = fu_ParseCmdString( cmd2.c_str() );
		if( !fu_CmdParamsToObject( cargs2, &err, &lpCmd2 ) ){
			printf("ERROR: %s [agWLzY]\n", err.c_str() );
			return 0;
		}
		assert( lpCmd2 );
		if( !lpCmd2->exec2() && !bContnOnError ){
			return 0;
		}
	}
	return 1;
}

/// Reinits stream pointer with close and open calls.
/// Stream pointer should be assumed in undefined position after doing this.
bool FU_Disk::reinitFileStream()
{
#	ifdef FU2_UNIX
		if( std::fclose( fph2 ) ){ // if err.
			return 0;
		}
		fph2 = nullptr;
		if( !(fph2 = std::fopen( srDiskFname.c_str(), srModeStr.c_str() ) ) ){
			return 0;
		}
#	endif
	return 1;
}

bool FU_CmdInject::exec2()
{
	if( !FU_OpenedDisk ){
		printf("ERROR: No disk opened.\n");
		return 0;
	}
	std::string srSrc2, srDest2; bool bContiguous = 1;
	auto endd = CmdArgs.aArgs.end();
	for( auto a = CmdArgs.aArgs.begin(); a != endd; ++a ){
		if( *a == "-o" ){
			bContiguous = 0;
		}else if( srSrc2.empty() ){
			srSrc2 = *a;
		}else if( srDest2.empty() ){
			srDest2 = *a;
		}
	}
	if( srSrc2.empty() ){
		printf("ERROR: No source file on the command line.\n" );
		return 0;
	}
	return injectFile( srSrc2, srDest2, bContiguous, 0, "", 0, {0,0,}, 0 );
}
bool FU_CmdInject::
injectFile( std::string srSrc2, std::string srDest2, bool bContiguous2,
				bool bQuiet,
				const char* prefix2,
				uint64_t addr2,
				std::pair<bool,uint64_t> uMaxSize,
				bool bOpenAlways )
{
	if( !hf_FileExists( srSrc2.c_str() ) ){
		printf("ERROR: Source file not found.\n" );
		printf("       [%s]\n", srSrc2.c_str() );
		return 0;
	}
	FSIZE_t fsize2 = 0;
	{
		uint64_t fsize3 = hf_GetFileSize64Fn( srSrc2.c_str() );
		fsize3 = ( uMaxSize.first ? std::min<uint64_t>(fsize3,uMaxSize.second) : fsize3 );
		if( fsize3 > FU_MaxFAT32FileSize ){
			printf("ERROR: Source file size is too large.\n");
			printf("       %s\n", HfArgs("FAT32 allowed maximum file size is %1 bytes. Requested %2.")
								.arg( FU_MaxFAT32FileSize ).arg( fsize3 ).c_str() );
			return 0;
		}else{
			fsize2 = static_cast<FSIZE_t>( fsize3 );
		}
	}
	if( !srDest2.empty() && srDest2[0] != '/' ){
		srDest2 = FU_OpenedDisk->getCDPathTo( srDest2 );
	}else if( srDest2.empty() ){ // if need to auto gen dest-file-name in CD.
		srDest2 = FU_OpenedDisk->getCDPathTo( hf_basename(srSrc2.c_str()) );
	}
	if(!bQuiet){
		printf("INFO: Injecting file, from-to:\n");
		printf("      [%s]\n", srSrc2.c_str() );
		printf("      [%s]\n", srDest2.c_str() );
	}
	FILE* fp2 = nullptr; uint8_t* bfrRw2 = nullptr;
	std::pair<bool,FIL> fi2( 0, FIL() );
	std::shared_ptr<void> raii2( 0, [&](void*){
		if( fi2.first ){
			f_close( &fi2.second );
			fi2.first = 0;
		}
		if( fp2 ){
			fclose( fp2 );
			fp2 = nullptr;
		}
		if( bfrRw2 ){
			free( bfrRw2 );
			bfrRw2 = nullptr;
		}
	});
	if( bContiguous2 && fsize2 ){
		if( !FU_CmdMkfile::createAllocFile( srDest2.c_str(), fsize2, &fi2.second, bQuiet ) )
			return 0;
		fi2.first = 1;
	}else{
		BYTE flags2 = (FA_WRITE | (bOpenAlways ? FA_OPEN_ALWAYS : FA_CREATE_NEW));
		FRESULT rs5 = f_open( &fi2.second, srDest2.c_str(), flags2 );
		if( rs5 != FR_OK ){
			printf("ERROR: Failed creating disk file. Code:%d [oKNrhpH]\n", rs5 );
			printf("       [%s]\n", srDest2.c_str() );
			return 0;
		}
		fi2.first = 1;
	}
	fp2 = std::fopen( srSrc2.c_str(), "rb" );
	if( !fp2 ){
		std::string err = std::strerror(errno);
		printf("ERROR: Failed opening file for read access [h1SOt1H]\n");
		printf("       [%s]\n", err.c_str() );
		printf("       [%s]\n", srSrc2.c_str() );
		return 0;
	}
	bfrRw2 = (uint8_t*) malloc( FU_Params2->uBuffRWSize );
	uint64_t uNumBtsDone = 0; UINT nWrtn;
    for( int ii4=0; ; ii4++ ){
		if( !hf_Seek64( fp2, uNumBtsDone + addr2 ) ){
			printf("\n""ERROR: hf_Seek64() failed [4FqkHnY]\n");
			break;
		}
		uint64_t nToRead = std::min<uint64_t>( FU_Params2->uBuffRWSize, (fsize2-uNumBtsDone) );
        uint64_t nReadd = std::fread( bfrRw2, 1, nToRead, fp2 );
        if( !nReadd ) break;
        if( FR_OK != f_lseek( &fi2.second, uNumBtsDone ) ){
			printf("\n""ERROR: f_lseek() failed [lJbrqC]\n");
			break;
        }
        if( !ii4 && !bQuiet ){
			printf("INFO: Writing data.\n");
        }
		if( FR_OK != f_write( &fi2.second, bfrRw2, nReadd, &nWrtn ) ){
			printf("\n""ERROR: f_write() failed [zqqFQYr]\n");
			break;
		}
		if( nWrtn < nReadd ) break;  // if error or disk full.
		if( FU_Params2->bSyncOnBfrWrite ){
			if( FR_OK != f_sync( &fi2.second ) ){
				printf("\n""ERROR: f_sync() failed [10N8sMj]\n");
				break;
			}
		}
		uNumBtsDone += nReadd;
		fu_PrintCRPercentage( uNumBtsDone, fsize2, 99.98, prefix2 );//bQuiet
		if( nToRead != FU_Params2->uBuffRWSize )
			break;
    }
    if( FU_Params2->bDiskReinitOnWriteEnd ){
		assert( FU_OpenedDisk );
		// On unix, when not using fsync(), alternate way
		// of ensuring that data reaches the hardware, before the
		// file is closed, is by closing and reopening the file.
		// Otherwise, without fsync, the write data
		// appears to be buffered to the point that the last fwrite() call completes
		// much faster, aprox 50% of actual speed, than the actual data
		// completes its way to the hardware.
		// Reopening the file pointer (FILE*) seems to be alternate
		// solution to fsync() calls. That is, performing fsync() call
		// for every fwrite().
		// On Windows, equivalent is FILE_FLAG_NO_BUFFERING flag.
		if( !FU_OpenedDisk->reinitFileStream() ){
			printf("ERROR: Failed reinit on the disk stream [18aCVxEr]\n");
			return 0;
		}
    }
    fu_PrintCRPercentageEnd( prefix2 );//bQuiet
    //printf("\n"); //perc
    if( fsize2 != uNumBtsDone ){
		printf("ERROR: Failed writting all the bytes to the disk file. [Ht9Vjj]\n");
		printf("       %s\n", HfArgs("Requested: %1, written: %2").arg( fsize2 ).arg( uNumBtsDone ).c_str() );
		return 0;
    }
	return 1;
}

/// Prints percentage to STDOUT using carriage return (CR) character for line erase.
/// Two input unsigned integers define current percent position.
/// \param ffMaxPercShow - max value for percentage to appear,
///        regardless of the integer position.
///        This should be typically set to some value close to 99%.
///        Later call to fu_PrintCRPercentageEnd() prints
///        the desired 100% value unconditionally.
///        Set this parameter to 0.0 to not use.
/// \sa fu_PrintCRPercentageEnd()
void fu_PrintCRPercentage( uint64_t uNumDone, uint64_t uNumTotal, double ffMaxPercShow, const char* szPrefix )
{
	double perc = (double(uNumDone) / uNumTotal);
	if( ffMaxPercShow != 0.0 && ffMaxPercShow < 100.0 ){
		perc = std::min<double>( perc, (ffMaxPercShow / 100.0) );
	}
	printf("\r%s%.2f%%", szPrefix, (float(perc) * 100.f) );
	fflush( stdout );
}
/// Ends percentage printing.
/// \sa fu_PrintCRPercentage()
void fu_PrintCRPercentageEnd( const char* szPrefix )
{
	printf("\r%s%.2f%%\n", szPrefix, 100.0f );
	fflush( stdout );
}


bool FU_CmdShowDisks::exec2()
{
	std::vector<FU_DiskVolume> dvlist;
	fu_EnumeratePhysicalDrives( &dvlist );
	if( !dvlist.empty() ){
		#if FU2_WINXX
			for( const auto& dv3 : dvlist ){
				const char* tab2 = "    ";
				printf("Disk %d\n", dv3.nOrderNr );
				printf("%s""Name         : %s\n", tab2, dv3.srShortName.c_str() );
				printf("%s""Status       : %s\n", tab2, ( dv3.bAccessible ? "OK." : ( !dv3.srErrorIfAny.empty() ? dv3.srErrorIfAny.c_str() : "Unknown status." ) ) );
				if( !dv3.bAccessible )
					continue;
				printf("%s""Volume Label : %s\n", tab2, ( !dv3.srVolLabel.empty() ? dv3.srVolLabel.c_str() : "<none>" ) );
			//	printf("%s""Size         : %s\n", tab2, HfArgs("%1").arg(dv3.uSize).c_str() );
				printf("%s""Sector Size  : %u\n", tab2, dv3.uSectorSize );
				if( !dv3.srFSName.empty() ){
					printf("%s""Type         : %s\n", tab2,
								(  dv3.srFSName.empty() ?
									"Unknown disk" :
								( ( !strcmp("FAT",dv3.srFSName.c_str()) || !strcmp("FAT32",dv3.srFSName.c_str()) ) ?
									"FAT32" :
									"Not a FAT32 disk" ) ) );
				}
			}
		#else
			size_t uMaxLen = 0;
			for( const auto& dv3 : dvlist ){
				uMaxLen = std::max<size_t>( dv3.srShortName.size(), uMaxLen );
			}
			for( const auto& dv3 : dvlist ){
				std::string sr2;
				sr2.resize( (uMaxLen - dv3.srShortName.size()), '\x20');
				printf("%s%s  %s B\n",
						dv3.srShortName.c_str(), sr2.c_str(),
						HfArgs("%1").arg(dv3.uSize).c_str() );
			}

		#endif
	}else{
		printf("No system disks found.\n");
	}
	return 1;
}
std::string fu_StrJoinAutoGlue( std::string inpA, std::string inpB, char cDfltGlue, const char* szGlueChars )
{
	char cGlue = ( cDfltGlue ? cDfltGlue : '_' );
	szGlueChars = ( szGlueChars && *szGlueChars ? szGlueChars : "\x20_-." );
	{
		const char* sz2 = 0;
		if( !sz2 && (sz2 = std::strpbrk( inpA.c_str(), szGlueChars )) ){
			cGlue = *sz2;
		}
		if( !sz2 && (sz2 = std::strpbrk( inpB.c_str(), szGlueChars )) ){
			cGlue = *sz2;
		}
	}
	inpA = hf_trim_stdstring<char>( inpA.c_str(), szGlueChars );
	inpB = hf_trim_stdstring<char>( inpB.c_str(), szGlueChars );
	if( !inpA.empty() && !inpB.empty() ){
		inpA.append( &cGlue, 1 );
	}
	return ( inpA + inpB );
}
std::string FU_Disk::getCDPathTo( std::string srSubPath )const
{
	if( srSubPath.empty() ){
		return "";
	}
	if( !srSubPath.empty() && srSubPath[0] == '/' ){
		return srSubPath;
	}
	std::string outp = HfArgs("/%1%2%3")
			.arg( hf_trim_stdstring<char>( srCurrentDir.c_str(), "/").c_str() )
			.arg( srCurrentDir.empty() ? "" : "/" )
			.arg( srSubPath.c_str() ).c_str();
	return outp;
}
FRESULT
fu_PutDiskFileContents( const char* fname, BYTE uModeOpen, const void* ptr, uint64_t uNumBytes )
{
	//f_open( ,, FA_WRITE|FA_OPEN_ALWAYS );
	//f_open( ,, FA_READ|FA_OPEN_EXISTING );
	FRESULT rs2; FIL fi2;
	std::shared_ptr<void> raii3( 0, [&](void*){
		if( fi2.obj.fs ){
			f_close( &fi2 );
			fi2.obj.fs = 0;
		}
	});
	if( FR_OK != (rs2 = f_open( &fi2, fname, uModeOpen )) ){
		return rs2;
	}
	assert( fi2.obj.fs );
	//FSIZE_t uFsize = f_size( &fi3.second );
//	rs2 = f_lseek( &fi3.second, uFsize );
//	if( rs2 != FR_OK ){
//		*err2 = "Failed moving file pointer [fMpb3gD]";
//		return 0;
//	}
	UINT nWritten = 0;
	rs2 = f_write( &fi2, ptr, uNumBytes, &nWritten );
	if( rs2 != FR_OK || nWritten != uNumBytes ){
		rs2 = ( rs2 != FR_OK ? rs2 : FR_INT_ERR );
		return rs2;
	}
	return FR_OK;
}
/**
	Gets disk dir contents.
	\param flags2 - flags, eg. \ref FU_DCShowFragm.
*/
std::vector<std::vector<std::string> >
fu_GetDiskDirContentsD2( std::string srDir, int flags2 )
{
	assert( !( flags2 & FU_DCFilesOnly && flags2 & FU_DCDirsOnly ) );
	assert( !( flags2 & FU_DCDirSlMark && flags2 & FU_DCAbsPaths ) );
	std::vector<std::vector<std::string> > outp;
	FRESULT res; DIR dir; FILINFO fno;
	res = f_opendir( &dir, srDir.c_str() );
	if( res == FR_OK ){
		for(;;){
			res = f_readdir(&dir, &fno);                   // Read a directory item
			if (res != FR_OK || fno.fname[0] == 0) break;  // Break on error or end of dir
			const bool bDir = ( fno.fattrib & AM_DIR );
			if( bDir && flags2 & FU_DCFilesOnly )
				continue;
			if( !bDir && flags2 & FU_DCDirsOnly )
				continue;
			std::vector<std::string> ln2;
			{
				std::string fn2 = fno.fname;
				if( flags2 & FU_DCAbsPaths ){
					fn2 = FU_OpenedDisk->getCDPathTo( fn2 );
				}
				if( flags2 & FU_DCDirSlMark && bDir ){
					fn2 = (std::string("/") + fn2);
				}
				ln2.push_back( fn2 );
			}
			ln2.push_back( bDir ? "-" : std::to_string( fno.fsize ).c_str() );
			if( flags2 & FU_DCShowFragm ){
				if( bDir ){
					ln2.push_back("-");  // showing nothing for dirs.
				}else{
					std::string fn3;
					fn3 = FU_OpenedDisk->getCDPathTo( fno.fname );
					bool bContn = 0;
					bool bOkk = ( FR_OK == fu_TestContiguousFile( fn3.c_str(), &bContn ) );
					ln2.push_back( bOkk ? (bContn ? "1" : "2+") : "??" );
				}
			}
			outp.push_back( ln2 );
		}
		f_closedir(&dir);
	}
	return outp;
}



