
#ifndef FU2_ULCFG_H_INCLUDED
#define FU2_ULCFG_H_INCLUDED
#include "fu2_general.h"
enum{
	FU_UlUsbAdvanceSplitSize = 1073741824,
};
struct FU_CmdUlInject : FU_CmdBase{
	virtual bool exec2()override;
	static auto createUlCfgEntry( const char* szTitle, std::string srGameIdWthDot ) -> std::vector<uint8_t>;
	static bool addUlCfgTitleFromText( std::string srTitlePlusGmId, std::string srUlCfgPath, std::string* err );
	static bool addUlCfgTitleFS( std::string srTitle, std::string srGameId, std::string srUlCfgPath, std::string* err );
	static bool addUlCfgTitleD2( std::string srTitle, std::string srGameId, std::string srUlCfgPath, std::string* err );
};

struct FU_CmdUlList : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdUlDelete : FU_CmdBase{
	virtual bool exec2()override;
};
/// Used internnally.
struct FU_UlPartFile{
	FSIZE_t             uFSize = 0;
	std::string         srBname;
	std::string         srPathname;
	uint64_t            addr2 = 0;
	bool                bAllocated2 = 0;
};
/// Structure for use with fu_GetPs2GameIdFromData2()
/// and fu_GetPs2GameIdFromFile() functions.
/// Invalid if 'uIdPart' member is zero.
struct FU_GameId{
	std::string              srStrPart;
	uint32_t                 uIdPart = 0;
	std::pair<size_t,size_t> aPosEnd = {0,0,};
	std::string              srGameIdWithDot;
	std::string              srNewTitle; ///< requires \ref FU_GIGetNewTitle flag.
};
enum{
	/// Flags for fu_GetPs2GameIdFromData2().
	FU_GIGetNewTitle = 0x1,
};
struct FU_UlCfgEn{
	std::string          srTitle2;  ///< game title, up to 31 charracters long.
	std::string          srIdStr;   ///< eg. "SLUS_111.22", past the "ul." in "ul.SLUS_111.22".
	std::vector<uint8_t> aUlBytes;  ///< bytes past game-id text, 18 total.
};
auto fu_GetUsbAdvanceULCrc32( const char* string2 ) -> uint32_t;
bool fu_GetPs2GameIdFromData( const void* inp, uint64_t uNumBytes, std::pair<std::string,uint32_t>* outp, std::pair<size_t,size_t>* aPosEnd, std::string* srGameIdWithDotOut, std::string* srNewTitleOut );
auto fu_GetPs2GameIdFromData2( const void* inp, uint64_t uNumBytes, int flags2 ) -> FU_GameId;
auto fu_GetPs2GameIdFromFile( const char* szFname, uint64_t uMaxHdrRead ) -> FU_GameId;
auto fu_ParseUlCfgFileD2( const char* szFname, std::vector<FU_UlCfgEn>* outp, std::string* err ) -> FRESULT;
auto fu_CreateUlCfgFileData( const std::vector<FU_UlCfgEn>& entries5 ) -> std::vector<uint8_t>;
auto fu_GetInstalledGameFilesD2( std::string srDirname, std::string srTitle, std::string srGameIdWthDot ) -> std::vector<std::string>;

#endif //FU2_ULCFG_H_INCLUDED
