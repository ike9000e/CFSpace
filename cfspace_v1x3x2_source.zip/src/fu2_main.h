#ifndef FU2_MAIN_H_
#define FU2_MAIN_H_

#include <vector>
#include <string>
#include <stdio.h>
#include <assert.h>
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"
#include "fu2_general.h"
namespace hef{}
using namespace hef;

#endif //FU2_MAIN_H_
