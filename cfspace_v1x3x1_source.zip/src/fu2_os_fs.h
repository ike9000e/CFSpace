#ifndef FU2_OS_FS_H_
#define FU2_OS_FS_H_

//#include <limits>
//std::numeric_limits<DWORD>::max();
//template<class T> using fu_Max = std::numeric_limits<typename T>;


//template <class CharT> using mystring =
//    std::basic_string<CharT,std::char_traits<CharT>>;

#include <string>
#include <stdio.h>
#include <inttypes.h>
#include "hef/hef_str.h"
namespace hef {}
using namespace hef;

#if defined(_WIN32) || defined(_WIN64)
	//#error "Windows support is not implemented atm."
	#define FU2_WINXX 1
#elseif defined(__unix__)
	#define FU2_UNIX 1
#endif

struct FU_DiskVolume{
	bool        bAccessible = 0;
	std::string srShortName;   // short name, eg. "D:" or "X:"
	std::string srPath;        // eg. "\\\\.\\C:"
	std::string srVolLabel;
	std::string srFSName;      // File system mane, eg. "FAT" or "NTFS".
	std::string srErrorIfAny;
	uint32_t    uSectorSize = 0;
	int         nOrderNr = 0;   // arbitrasry value assigned by this library
	uint64_t    uSize = 0;
};

bool fu_GetDeviceSectorSize( FILE* hf2, const char* szDiskPath, uint32_t *uSectorSizeOut );
bool fu_EnumeratePhysicalDrives( std::vector<FU_DiskVolume>* outp );

std::string fu_WinapiGetLastError();

#endif //FU2_OS_FS_H_

