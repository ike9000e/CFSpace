#include "fu2_intrf.h"
#include "ff.h"         // FatFs main header.
#include "diskio.h"		// Declarations of disk functions
#include "fu2_general.h"
#ifdef FU2_UNIX
#	include <unistd.h>   //fsync()
#endif

static_assert( sizeof(WCHAR)==2, "" );
static_assert( sizeof(TCHAR)==1, "" );

//-----------------------------------------------------------------------
// Get Drive Status
//-----------------------------------------------------------------------

DSTATUS disk_status (
	BYTE pdrv		// Physical drive nmuber to identify the drive
)
{
	//assert(!"N.I. [vLawDCU]");
	//DSTATUS stat = STA_NOINIT;
	//int result;

	//return STA_NOINIT;
	return 0;
}

//-----------------------------------------------------------------------
// Inidialize a Drive
//-----------------------------------------------------------------------

DSTATUS disk_initialize (
	BYTE pdrv				// Physical drive nmuber to identify the drive
)
{
	//printf("disk_initialize(%d) [4RsptsP]\n", (int)pdrv );
	//return STA_NOINIT;
	return 0;
}

#ifdef FU2_WINXX

bool fu_WinapiSeek( HANDLE hFile, uint64_t pos2 )
{
	static_assert( sizeof(LONG) == 4, "" );
	LONG nPos     = LONG( pos2 & 0xFFFFFFFF );
	LONG nPosHigh = LONG( pos2 >> 32 );
	if( 0xFFFFFFFF == SetFilePointer( hFile, nPos, &nPosHigh, FILE_BEGIN ) ){
		return 0;
	}
	return 1;
}
#endif
//-----------------------------------------------------------------------
// Read Sector(s)
//-----------------------------------------------------------------------

DRESULT disk_read (
	BYTE pdrv,		// Physical drive nmuber to identify the drive
	BYTE *buff,		// Data buffer to store read data
	LBA_t nSector,	// Start sector in LBA
	UINT nCount		// Number of sectors to read
)
{
	//printf("disk_read(%d,,%u,%u) [c8gpqExB]\n",
	//		(int)pdrv, (uint32_t)nSector, (uint32_t)nCount );
	assert( FU_OpenedDisk );
	const FU_Disk* dsk = FU_OpenedDisk;
	const uint64_t bgn = uint64_t(dsk->uSectorSize) * nSector;
	const uint64_t endd = bgn + uint64_t(dsk->uSectorSize) * nCount;
	const uint64_t numread = endd - bgn;
#	ifdef FU2_WINXX
		assert( dsk->handle2 );
		if( !fu_WinapiSeek( dsk->handle2, bgn ) ){
			return RES_ERROR;
		}
		if( numread ){
			DWORD nReadd = 0;
			assert( numread <= uint64_t( HfLimits<DWORD>::max_() ) );
			if( !ReadFile( dsk->handle2, buff, numread, &nReadd, nullptr ) ){
				return RES_ERROR;
			}
			if( uint64_t(nReadd) != numread ){
				return RES_ERROR;
			}
		}
#	else
		assert( dsk->fph2 );
		if( !hf_Seek64( dsk->fph2, bgn ) ){
			//printf("[7B5LXo0]\n");
			return RES_ERROR;
		}
		if( 1 != std::fread( buff, numread, 1, dsk->fph2 ) ){
			//printf("[GuT7vCC]\n");
			return RES_ERROR;
		}
#	endif
	return RES_OK;
}

//-----------------------------------------------------------------------
// Write Sector(s)
//-----------------------------------------------------------------------

#if FF_FS_READONLY == 0   //[wMO2h39Ya] {

DRESULT disk_write (
	BYTE pdrv,			// Physical drive nmuber to identify the drive
	const BYTE *buff,	// Data to be written
	LBA_t nSector,		// Start sector in LBA
	UINT nCount			// Number of sectors to write
)
{
	//printf("disk_write(%d,,%u,%u) [v8gp4qj4x]\n",
	//		(int)pdrv, (uint32_t)nSector, (uint32_t)nCount );
	assert( FU_OpenedDisk );
	assert( FU_OpenedDisk->uSectorSize > 0 );
	const FU_Disk* dsk = FU_OpenedDisk;
	const uint64_t bgn = uint64_t(dsk->uSectorSize) * nSector;
	const uint64_t endd = bgn + uint64_t(dsk->uSectorSize) * nCount;
	const uint64_t numbytes = endd - bgn;
#	ifdef FU2_WINXX
		assert( dsk->handle2 );
		if( !fu_WinapiSeek( dsk->handle2, bgn ) ){
			//printf("ERROR: [94kck3lgneopke]\n");
			return RES_ERROR;
		}
		if( numbytes ){
			DWORD nWritten = 0;
			assert( numbytes <= uint64_t( HfLimits<DWORD>::max_() ) );
			if( !WriteFile( dsk->handle2, buff, numbytes, &nWritten, nullptr ) ){
				//printf("ERROR: [%s] [95klnoklg0]\n", fu_WinapiGetLastError().c_str() );
				return RES_ERROR;
			}
			if( uint64_t(nWritten) != numbytes ){
				//printf("ERROR: [96rk402kcge]\n");
				return RES_ERROR;
			}
		}
#	else
		assert( dsk->fph2 );
		if( !hf_Seek64( dsk->fph2, bgn ) ){
			//printf("ERROR: hf_Seek64\n");
			return RES_ERROR;
		}
		if( 1 != std::fwrite( buff, numbytes, 1, dsk->fph2 ) ){
			//printf("ERROR: std::fwrite\n");
			return RES_ERROR;
		}
#	endif
	return RES_OK;
}

#endif   // [wMO2h39Ya] }

//-----------------------------------------------------------------------
// Miscellaneous Functions
//-----------------------------------------------------------------------

DRESULT disk_ioctl (
	BYTE pdrv,		// Physical drive nmuber (0..)
	BYTE cmd,		// Control code
	void *buff		// Buffer to send/receive control data
)
{
	//printf("disk_ioctl() cmd:%d\n", (int)cmd );
	//CTRL_SYNC			0	// Complete pending write process (needed at FF_FS_READONLY == 0)
	//GET_SECTOR_COUNT	1	// Get media size (needed at FF_USE_MKFS == 1)
	//GET_SECTOR_SIZE	2	// Get sector size (needed at FF_MAX_SS != FF_MIN_SS)
	//GET_BLOCK_SIZE	3	// Get erase block size (needed at FF_USE_MKFS == 1)
	//CTRL_TRIM			4	// Inform device that the data on the block of sectors is no longer used (needed at FF_USE_TRIM == 1)
	if( cmd == GET_SECTOR_COUNT ){
		// GET_SECTOR_COUNT is used by: create_partition() and f_mkfs()
		assert(!"disk_ioctl() - GET_SECTOR_COUNT not implemented.");
		return RES_OK;
	}else if( cmd == GET_BLOCK_SIZE ){   // f_mkfs()
		//DWORD* lpDw = (DWORD*)buff;
		assert(!"disk_ioctl() - GET_BLOCK_SIZE Not implemented.");
		//DWORD* lpDw = reinterpret_cast<DWORD*>(buff);
		//-*lpDw = FU_CommonBlockSize;
		return RES_OK;
	}else if( cmd == GET_SECTOR_SIZE ){
		WORD* lpWrd = reinterpret_cast<WORD*>(buff);
		assert( FU_OpenedDisk != nullptr );
		*lpWrd = static_cast<WORD>( FU_OpenedDisk->uSectorSize );
		//printf("disk_ioctl() - GET_SECTOR_SIZE ret: %d\n", (int)(*lpWrd) );
		return RES_OK;
	}else if( cmd == CTRL_SYNC ){
		//printf("disk_ioctl() - CTRL_SYNC\n");
		// fflush (for FILE*),
		// ref: https://stackoverflow.com/a/13358458
		/*
			https://stackoverflow.com/a/13358458

			fflush (for FILE*), std::flush (for IOStream) to force your program to send to the OS.
			POSIX has
				sync(2) to ask to schedule writing its buffers, but can return before the writing is done (Linux is waiting that the data is send to the hardware before returning).
				fsync(2) which is guaranteed to wait for the data to be send to the hardware, but needs a file descriptor (you can get one from a FILE* with fileno(3), I know of no standard way to get one from an IOStream).
				O_SYNC as a flag to open(2).
			In all cases, the hardware may have it's own buffers (but if it has control on it, a good implementation will try to flush them also and ISTR that some disks are using capacitors so that they are able to flush whatever happens to the power) and network file systems have their own caveat.
		*/
		/*
			https://stackoverflow.com/a/13358691

			You can use fsync()/fdatasync() to force(Note 1) the data onto the storage. Those requres a file descriptor, as given by e.g. open(). The linux manpage have more linux specific info, particularly on the difference of fsync and fdatasync.
			If you don't use file desciptors directly, many abstractions will contain internal buffers residing in your process.
			e.g. if you use a FILE*, you first have to flush the data out of your application.
				//... open and write data to a FILE *myfile
				fflush(myfile);
				fsync(fileno(myfile));
			Note 1: These calls force the OS to ensure that any data in any OS cache is written to the drive, and the drive acknowledges that fact. Many hard-drives lie to the OS about this, and might stuff the data in cache memory on the drive.
		*/
		assert( FU_OpenedDisk );

//#		ifdef FU2_WINXX
//			assert( FU_OpenedDisk->handle2 );
//			if( std::fflush( FU_OpenedDisk->fph2 ) ){	//if error.
//				return RES_ERROR;
//			}
//#		endif
#		ifdef FU2_UNIX
			assert( FU_OpenedDisk->fph2 );
			if( fsync( fileno( FU_OpenedDisk->fph2 ) ) ){
				return RES_ERROR;
			}
#		endif
		return RES_OK;
	}
	printf("cmd:%d\n", (int)cmd );
	assert(!"Not meant to be reached [FeHKrEw]");
	return RES_PARERR;
}

DWORD get_fattime( void )
{
	//assert(!"get_fattime() - N.I. [ueWoJ2i]");
	return 0;
}
