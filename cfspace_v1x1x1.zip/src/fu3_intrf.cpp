#include "fu3_intrf.h"
#include "ff.h"         // FatFs main header.
#include "diskio.h"		// Declarations of disk functions
#include "fu2_general.h"

static_assert( sizeof(WCHAR)==2, "" );
static_assert( sizeof(TCHAR)==1, "" );

//-----------------------------------------------------------------------
// Get Drive Status
//-----------------------------------------------------------------------

DSTATUS disk_status (
	BYTE pdrv		// Physical drive nmuber to identify the drive
)
{
	//assert(!"N.I. [vLawDCU]");
	//DSTATUS stat = STA_NOINIT;
	//int result;

	//return STA_NOINIT;
	return 0;
}

//-----------------------------------------------------------------------
// Inidialize a Drive
//-----------------------------------------------------------------------

DSTATUS disk_initialize (
	BYTE pdrv				// Physical drive nmuber to identify the drive
)
{
	//printf("disk_initialize(%d) [4RsptsP]\n", (int)pdrv );
	//return STA_NOINIT;
	return 0;
}

//-----------------------------------------------------------------------
// Read Sector(s)
//-----------------------------------------------------------------------

DRESULT disk_read (
	BYTE pdrv,		// Physical drive nmuber to identify the drive
	BYTE *buff,		// Data buffer to store read data
	LBA_t nSector,	// Start sector in LBA
	UINT nCount		// Number of sectors to read
)
{
	//printf("disk_read(%d,,%u,%u) [c8gpqExB]\n",
	//		(int)pdrv, (uint32_t)nSector, (uint32_t)nCount );
	assert( FU_OpenedDisk );
	const FU_Disk* dsk = FU_OpenedDisk;
	assert( dsk->fph2 );
	const uint64_t bgn = uint64_t(dsk->uSectorSize) * nSector;
	const uint64_t endd = bgn + uint64_t(dsk->uSectorSize) * nCount;
	const uint64_t numread = endd - bgn;
	if( !hf_Seek64( dsk->fph2, bgn ) ){
		//printf("[7B5LXo0]\n");
		return RES_ERROR;
	}
	if( 1 != std::fread( buff, numread, 1, dsk->fph2 ) ){
		//printf("[GuT7vCC]\n");
		return RES_ERROR;
	}
	return RES_OK;
}

//-----------------------------------------------------------------------
// Write Sector(s)
//-----------------------------------------------------------------------

#if FF_FS_READONLY == 0   //[wMO2h39Ya] {

DRESULT disk_write (
	BYTE pdrv,			// Physical drive nmuber to identify the drive
	const BYTE *buff,	// Data to be written
	LBA_t nSector,		// Start sector in LBA
	UINT nCount			// Number of sectors to write
)
{
	assert( FU_OpenedDisk );
	const FU_Disk* dsk = FU_OpenedDisk;
	assert( dsk->fph2 );
	const uint64_t bgn = uint64_t(dsk->uSectorSize) * nSector;
	const uint64_t endd = bgn + uint64_t(dsk->uSectorSize) * nCount;
	const uint64_t numbytes = endd - bgn;
	if( !hf_Seek64( dsk->fph2, bgn ) ){
		return RES_ERROR;
	}
	if( 1 != std::fwrite( buff, numbytes, 1, dsk->fph2 ) ){
		return RES_ERROR;
	}
	return RES_OK;
}

#endif   // [wMO2h39Ya] }

//-----------------------------------------------------------------------
// Miscellaneous Functions
//-----------------------------------------------------------------------

DRESULT disk_ioctl (
	BYTE pdrv,		// Physical drive nmuber (0..)
	BYTE cmd,		// Control code
	void *buff		// Buffer to send/receive control data
)
{
	//printf("disk_ioctl() cmd:%d\n", (int)cmd );
	//CTRL_SYNC			0	// Complete pending write process (needed at FF_FS_READONLY == 0)
	//GET_SECTOR_COUNT	1	// Get media size (needed at FF_USE_MKFS == 1)
	//GET_SECTOR_SIZE	2	// Get sector size (needed at FF_MAX_SS != FF_MIN_SS)
	//GET_BLOCK_SIZE	3	// Get erase block size (needed at FF_USE_MKFS == 1)
	//CTRL_TRIM			4	// Inform device that the data on the block of sectors is no longer used (needed at FF_USE_TRIM == 1)
	if( cmd == GET_SECTOR_COUNT ){
		// GET_SECTOR_COUNT is used by: create_partition() and f_mkfs()
		assert(!"disk_ioctl() - GET_SECTOR_COUNT Not implemented.");
	/*	printf("disk_ioctl() - GET_SECTOR_COUNT\n");
		assert( FU_OpenedDisk );
		const FU_Disk* dsk2 = FU_OpenedDisk;
		uint64_t nNumSectors = uint64_t(dsk2->uFileSize) / dsk2->uSectorSize;
		bool bOOB = ( std::numeric_limits<LBA_t>::max() < nNumSectors );
        if( bOOB ){
			printf("WARNING: number of sectors is larger than can be stored on the 'LBA_t' type [ThdyiFS]\n");
        }
        LBA_t* lpDwLBA = reinterpret_cast<LBA_t*>(buff);
        *lpDwLBA = static_cast<LBA_t>( nNumSectors );//*/
		return RES_OK;
	}else if( cmd == GET_BLOCK_SIZE ){   // f_mkfs()
		//DWORD* lpDw = (DWORD*)buff;
		assert(!"disk_ioctl() - GET_BLOCK_SIZE Not implemented.");
		//DWORD* lpDw = reinterpret_cast<DWORD*>(buff);
		//-*lpDw = FU_CommonBlockSize;
		return RES_OK;
	}else if( cmd == GET_SECTOR_SIZE ){
		WORD* lpWrd = reinterpret_cast<WORD*>(buff);
		assert( FU_OpenedDisk != nullptr );
		*lpWrd = static_cast<WORD>( FU_OpenedDisk->uSectorSize );
		//printf("disk_ioctl() - GET_SECTOR_SIZE ret: %d\n", (int)(*lpWrd) );
		return RES_OK;
	}else if( cmd == CTRL_SYNC ){
		//printf("disk_ioctl() - CTRL_SYNC\n");
		// fflush (for FILE*),
		// ref: https://stackoverflow.com/a/13358458
		assert( FU_OpenedDisk );
		assert( FU_OpenedDisk->fph2 );
		if( std::fflush( FU_OpenedDisk->fph2 ) ){	//if error.
			return RES_ERROR;
		}
		return RES_OK;
	}
	printf("cmd:%d\n", (int)cmd );
	assert(!"Not meant to be reached [FeHKrEw]");
	return RES_PARERR;
}

DWORD get_fattime( void )
{
	//assert(!"get_fattime() - N.I. [ueWoJ2i]");
	return 0;
}
