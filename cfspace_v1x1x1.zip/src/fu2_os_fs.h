#ifndef FU2_OS_FS_H_
#define FU2_OS_FS_H_

#include <stdio.h>
#include <inttypes.h>

#ifdef WIN32
	#error "Windows support is not implemented atm."
	#define FU2_WIN32 1
#elif defined(__GNUC__)
	#define FU2_GNUC 1
#endif

bool fu_GetDeviceSectorSize( FILE* hf2, uint32_t *uSectorSizeOut );

#endif //FU2_OS_FS_H_

