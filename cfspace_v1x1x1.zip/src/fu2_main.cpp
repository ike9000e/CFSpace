#include "fu2_main.h"
#include <memory>

static_assert( sizeof(WCHAR)==2, "" );
static_assert( sizeof(TCHAR)==1, "" );

int main( int argc, const char*const* argv )
{
	assert( !FU_OpenedDisk );
	assert( !FU_Params2 );
	FU_Params2 = new FU_AppParams;
	std::shared_ptr<void> raii2( 0, [&](void*){
		if(FU_Params2){
			delete FU_Params2;
			FU_Params2 = 0;
		}
	});
	for( int ii2 = 1; ii2 < argc; ii2++ ){
		const char* arg2 = argv[ii2];
		if(0){
		}else if( !strcmp( arg2, "--open_disk" ) && ii2+1 < argc ){
			FU_Params2->srInitialDiskOpen = argv[++ii2];
		}else if( !strcmp( arg2, "--read_only" ) && ii2+1 < argc ){
			FU_Params2->bOpenReadOnly = !!atoi( argv[++ii2] );
		}else if( !strcmp( arg2, "--current_dir" ) && ii2+1 < argc ){
			FU_Params2->srInitialCurDir = argv[++ii2];
		}else if( !strcmp( arg2, "--error_exit" ) ){
			FU_Params2->bExitOnCmdError = 1;
		}else if( !strcmp( arg2, "--buff_rw_size" ) && ii2+1 < argc ){
			FU_Params2->uBuffRWSize = std::strtoul( argv[++ii2], 0, 10 );
		}else if( !strcmp( arg2, "--run_cmd" ) && ii2+1 < argc ){
			FU_Params2->srRunCmd = argv[++ii2];
		}else if( !strcmp( arg2, "--no_disk_reinit_w" ) && ii2+1 < argc ){
			FU_Params2->bDiskReinitOnWriteEnd = 0;
		}else if( !strcmp( arg2, "--write_sync" ) && ii2+1 < argc ){
			FU_Params2->bSyncOnBfrWrite = 1;
		}
	}
	if( !FU_Params2->srInitialDiskOpen.empty() ){
		printf("INFO: Opening disk on startup...\n");
		FU_CmdOpen::openDiskOnStartup(
				std::string(FU_Params2->srInitialDiskOpen.c_str()).c_str(),
				FU_Params2->bOpenReadOnly,
				FU_Params2->srInitialCurDir.c_str() );
	}
	bool rs2 = fu_EnterCmdLoop();
	printf("INFO: Program exit.\n");
	return ( rs2 ? 0 : 102 );
}

