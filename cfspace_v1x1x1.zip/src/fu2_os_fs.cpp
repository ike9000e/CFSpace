
#include "fu2_os_fs.h"
#ifdef FU2_GNUC
#	include <linux/fs.h>
#	include <sys/ioctl.h>
#endif
#include <algorithm>

//ioctl(file, BLKGETSIZE64, &file_size_in_bytes);
//
// c - Portable way to determine sector size in Linux
// https://stackoverflow.com/questions/40068904/portable-way-to-determine-sector-size-in-linux
// https://stackoverflow.com/a/40071188
//
// Linux-Kernel Archive: Re: Q: ioctl BLKGETSIZE return value unit
// http://lkml.iu.edu/hypermail/linux/kernel/0105.2/0744.html

/// Returns sector size of the opened file, typically a block device.
/// Input file can be eg. "/dev/sdc1".
/// This function fails on regular disk files, returning false.
/// Fails if there is not enough priviledges. Usually only root
/// can access disks in /dev directory.
bool fu_GetDeviceSectorSize( FILE* hf2, uint32_t *uSectorSizeOut )
{
#	ifdef FU2_WIN32
		#error "Windows support is not implemented ATM [oBpnEN]"
#	elif defined(FU2_GNUC)
		int sector_size = 0;
		*uSectorSizeOut = 0;
		int fd2 = fileno( hf2 );  // Note, no std::fileno() function.
		if( ioctl( fd2, BLKSSZGET, &sector_size ) >= 0 ){
			sector_size = std::max<int>( sector_size, 0 );
			*uSectorSizeOut = static_cast<uint32_t>( sector_size );
			return 1;
		}
		return 0;
#	endif
}
