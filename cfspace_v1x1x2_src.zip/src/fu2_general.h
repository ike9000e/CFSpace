#ifndef FU2_DISKIO_H_
#define FU2_DISKIO_H_

#include <vector>
#include <string>
#include <stdio.h>
#include <assert.h>
#include <cstring>
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"
#include "ff.h"   // FatFs main header.
#include "fu2_os_fs.h"
namespace hef{}
using namespace hef;

#ifndef FU2_WINXX
	typedef void* HANDLE;
#endif
enum : uint32_t{
	FU_CommonSectorSize = 512,
	//
	FU_CommonLineLength   = 64,
	FU_MaxFnameListingLen = int(FU_CommonLineLength * 0.64f),
	FU_MaxFAT32FileSize   = 4294967295, ///< FAT32 file limit is 4GiB-1, or exactly 4,294,967,295 bytes.
};
static_assert( FU_CommonLineLength > 3, "" );

struct FU_LastListing{

	std::vector<bool> aListCmd;
	std::string       srDir;
	bool              bFromDiskListing = 0;
};

struct FU_AppParams {
	std::string srInitialDiskOpen;
	std::string srInitialCurDir;
	bool        bOpenReadOnly = 0;
	bool        bExitOnCmdError = 0;
	uint32_t    uBuffRWSize = 1024*1024;  //65536, 1024*1024
	std::string srRunCmd;
	bool        bDiskReinitOnWriteEnd = 0;
	bool        bSyncOnBfrWrite = 1;
	FU_LastListing sLastListing;
};

struct FU_Disk {
	uint64_t    uFileSize = 0;
	std::string srDiskFname;
	std::FILE*  fph2 = nullptr;
	HANDLE      handle2 = nullptr;  //HANDLE
	std::string srModeStr;
	uint8_t     uFsIdent = 0;
	bool        bValid = 0;
	uint32_t    uSectorSize = 0;
	std::string srCurrentDir;
	FATFS*      lpFatFs = nullptr;
	//
	void        clear2();
	static void clear3( FU_Disk** );
	bool        reinitFileStream();
};
extern FU_Disk*      FU_OpenedDisk;
extern FU_AppParams* FU_Params2;


struct FU_CmdArgs{
	std::string              name2;
	std::vector<std::string> aArgs;
};
struct FU_SFileOr{
	FIL*        fpi2;
	std::string srFname;
	FU_SFileOr( FIL* fpi2_ ) : fpi2(fpi2_){}
	FU_SFileOr( const char* fname ) : fpi2(0), srFname(fname) {}
};
/*struct FU_SFileOr2{
	FIL*        fpi3;
	std::string srFname;
	FU_SFileOr2( FIL* fpi3_ ) : fpi3(fpi3_){}
	FU_SFileOr2( const char* fname ) : fpi3(0), srFname(fname) {}
	virtual ~FU_SFileOr2();
	FRESULT init2();
private:
	bool bOwnPtr = 0;
};//*/
struct FU_CmdBase {
	virtual ~FU_CmdBase() {}
	virtual void setCmdArgs( const FU_CmdArgs& cargs2 ) {CmdArgs = cargs2;}
	virtual bool exec2() {return 0;}
	virtual bool isExitCommand()const {return 0;}
protected:
	FU_CmdArgs CmdArgs;
};
struct FU_CmdExit : FU_CmdBase{
	virtual bool isExitCommand()const override {return 1;}
};
struct FU_CmdOpen : FU_CmdBase{
	virtual bool exec2()override;
	static void openDiskOnStartup( const char* szFname, bool bReadOnly3, const char* szCdir );
	static bool isPathSystemDisk( std::string inp );
	static auto convShortDiskPathToSystem( std::string inp ) -> std::string;
};
struct FU_CmdClose : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdLs : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdPwd : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdCd : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdDiskinfo : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdExtract : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdMkfile : FU_CmdBase{
	virtual bool exec2()override;
	static bool createAllocFile( const char* fpathname, FSIZE_t uRqFsize2, FIL* ouOpenedFile );
};
struct FU_CmdDelete : FU_CmdBase{
	virtual bool exec2()override;
	static FRESULT deleteFile( std::string srFname2, bool bClearROFlag2 );
};
struct FU_CmdInject : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdShowFr : FU_CmdBase{
	virtual bool exec2()override;
};
struct FU_CmdRunScript : FU_CmdBase{
	virtual bool exec2()override;
};

struct FU_CmdShowDisks : FU_CmdBase{
	virtual bool exec2()override;
};

struct FU_SCmdDfn{
	std::vector<std::string> names2;  ///< command name and aliases.
	std::function< std::string( void )> fnGetCommandHelp;
	std::function< FU_CmdBase*(void)> fnCreateCommand;
	void* reserved0;
	void* reserved1;
};
bool fu_EnterCmdLoop();
auto fu_ParseCmdString( const char* inp ) -> FU_CmdArgs;
bool fu_CmdParamsToObject( const FU_CmdArgs& cargs, std::string* err4, FU_CmdBase** outp );
auto fu_TestContiguousFile( FU_SFileOr sFileOr, bool* bCont ) -> FRESULT;
void fu_PrintCRPercentage( uint64_t uNumDone, uint64_t uNumTotal, double ffMaxPercShow );
void fu_PrintCRPercentageEnd(  );
uint32_t fu_GetUsbAdvanceULCrc32( const char* string2 );

#endif //FU2_DISKIO_H_
