
#ifndef FU2_ULCFG_H_INCLUDED
#define FU2_ULCFG_H_INCLUDED
#include "fu2_general.h"

struct FU_CmdUlCfgInject : FU_CmdBase{
	virtual bool exec2()override;

	static auto createUlCfgEntry( const char* szTitle, std::string srGameIdWthDot ) -> std::vector<uint8_t>;
	static bool getPs2GameIdFromText( std::string inp, std::pair<std::string,uint32_t>* outp, std::pair<size_t,size_t>* aPosEnd, std::string* srGmIdOut );
	static bool addUlCfgTitleFromText( std::string srTitlePlusGmId, std::string srUlCfgPath, std::string* err );
};


#endif //FU2_ULCFG_H_INCLUDED
