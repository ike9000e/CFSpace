//#include <limits>
#include "fu2_os_fs.h"
#ifdef FU2_WINXX
	#include <windows.h>
	#include <winioctl.h>
#endif
#ifdef FU2_UNIX
#	include <linux/fs.h>
#	include <sys/ioctl.h>
#endif
#include <assert.h>
#include <algorithm>
#include "hef/hef_str_args.h"

//ioctl(file, BLKGETSIZE64, &file_size_in_bytes);
//
// c - Portable way to determine sector size in Linux
// https://stackoverflow.com/questions/40068904/portable-way-to-determine-sector-size-in-linux
// https://stackoverflow.com/a/40071188
//
// Linux-Kernel Archive: Re: Q: ioctl BLKGETSIZE return value unit
// http://lkml.iu.edu/hypermail/linux/kernel/0105.2/0744.html

/// Returns sector size of the opened file, typically a block device.
/// Input file can be eg. "/dev/sdc1".
/// This function fails on regular disk files, returning false.
/// Fails if there is not enough priviledges. Usually only root
/// can access disks in /dev directory.
bool fu_GetDeviceSectorSize( FILE* hf2, const char* szDiskPath, uint32_t *uSectorSizeOut )
{
#	ifdef FU2_WINXX
		//#error "Windows \support is not implemented ATM [oBpnEN]"
		//assert(!"N.i. [xkegh2odjk]");
		assert( szDiskPath );
		assert( *szDiskPath );
		HANDLE ha3 = CreateFile( szDiskPath,
				GENERIC_READ, //FILE_READ_DATA | FILE_WRITE_DATA,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
		if( ha3 && ha3 != INVALID_HANDLE_VALUE ){
			DISK_GEOMETRY_EX dge; DWORD numret;
			bool rs2 = !!DeviceIoControl( ha3, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX,
						0, 0, &dge, sizeof(dge), &numret, 0 );
			if( rs2 ){
				*uSectorSizeOut = static_cast<uint32_t>( dge.Geometry.BytesPerSector );
			}else{
				DISK_GEOMETRY dg2;
				rs2 = !!DeviceIoControl( ha3, IOCTL_DISK_GET_DRIVE_GEOMETRY,
							0, 0, &dg2, sizeof(dg2), &numret, 0 );
				if( rs2 ){
					*uSectorSizeOut = static_cast<uint32_t>( dg2.BytesPerSector );
				}
			}//*/
			CloseHandle(ha3);
			ha3 = 0;
			return rs2;
		}
		return 0;
#	elif defined(FU2_UNIX)
		assert( hf2 );
		int sector_size = 0;
		*uSectorSizeOut = 0;
		int fd2 = fileno( hf2 );  // Note, no std::fileno() function.
		if( ioctl( fd2, BLKSSZGET, &sector_size ) >= 0 ){
			sector_size = std::max<int>( sector_size, 0 );
			*uSectorSizeOut = static_cast<uint32_t>( sector_size );
			return 1;
		}
#	endif
	return 0;
}

#ifdef FU2_WINXX

// Returns the last Win32 error, in string format.
// Returns an empty string if there is no error.
// ref: https://stackoverflow.com/a/17387176
std::string fu_WinapiGetLastError()
{
	DWORD errorMessageID = GetLastError();   // Get the error message, if any.
	if( !errorMessageID ){
		return "";   // No error message has been recorded
	}
	LPSTR messageBuffer = nullptr;
	size_t size2 = FormatMessageA(
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			nullptr, errorMessageID, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPSTR)&messageBuffer, 0, nullptr );
	std::string message2( messageBuffer, size2 );

	LocalFree(messageBuffer);   // Free the buffer.
	message2 = hf_trim_stdstring<char>( message2.c_str(), "\r\n\x20" );
	return message2;
}
#endif //FU2_WINXX


bool fu_EnumeratePhysicalDrives( std::vector<FU_DiskVolume>* outp2 )
{
	std::vector<FU_DiskVolume> outp3, *outp = ( outp2 ? outp2 : &outp3 );
#	ifdef FU2_WINXX
		// MSDN - Enumerate PhysicalDisk drives
		// ref: https://social.msdn.microsoft.com/Forums/en-US/3ca91786-be2d-424f-a3a7-11c63187d6e7/how-do-i-enumerate-physicaldisk-drives-its-not-obvious?forum=windowsgeneraldevelopmentissues
		//
		// MS - Direct Drive Access Under Win32
		// ref: https://support.microsoft.com/en-us/help/100027/info-direct-drive-access-under-win32
		DWORD dwDrives = GetLogicalDrives();
		for( DWORD ii2 = 0, iDisk = 0; ii2 < 32; ii2++ ){
			if( dwDrives & (1<<ii2) ){
				//QueryDosDevice( bfrPd, bfrTgPath, sizeof(bfrTgPath) );
				char bfrPd[256] = "", bfrLetter[16];
				snprintf( bfrLetter, sizeof(bfrLetter), "%c", ('A' + ii2) );
				snprintf( bfrPd, sizeof(bfrPd), "\\\\.\\%s:", bfrLetter );
				//printf("bfrPd: [%s]\n",  bfrPd );
				FU_DiskVolume dv2;
				dv2.nOrderNr    = static_cast<int>(iDisk++);
				dv2.srPath      = bfrPd;
				dv2.srShortName = HfArgs("%1:").arg( bfrLetter ).c_str();
				HANDLE hf2 = CreateFile( bfrPd,
						GENERIC_READ,// | GENERIC_WRITE,
						FILE_SHARE_READ | FILE_SHARE_WRITE,
						0, OPEN_EXISTING, FILE_FLAG_NO_BUFFERING, 0 );
				if( hf2 != INVALID_HANDLE_VALUE && hf2 ){

					char bfrFsName[32] = "", bfrVLabel[256];  //FAT or NTFS
					GetVolumeInformation(
							(std::string( bfrPd ) + "\\").c_str(),
							bfrVLabel, sizeof(bfrVLabel),
							0,0,0, bfrFsName, sizeof(bfrFsName) );
					//printf("fs: [%s] [%s]\n", bfrFsName, bfrVLabel );
					dv2.srFSName   = bfrFsName;
					dv2.srVolLabel = bfrVLabel;
					bool rs2 = fu_GetDeviceSectorSize( 0, dv2.srPath.c_str(), &dv2.uSectorSize );
					if(!rs2){
						dv2.srErrorIfAny = fu_WinapiGetLastError();
					}
					//printf("sector-size: %d\n", (int)dv2.uSectorSize );
					CloseHandle(hf2);
					hf2 = 0;
					dv2.bAccessible = rs2;
				}else{
					dv2.srErrorIfAny = fu_WinapiGetLastError();
					//printf("ERROR: [%s]\n", dv2.srErrorIfAny.c_str() );
				}
				outp->push_back( dv2 );
			}
		}
#	else
		//printf("Not implemented [t9fkv37g1]\n");

		// linux - get physical hdd's list in c - Stack Overflow
		// https://stackoverflow.com/a/9492610
		// read file: "/proc/partitions"
		// Example output:
		//   8        0   78150744 sda
		//   8        1     665600 sda1
		//   8        2   36864000 sda2
		//   8       16  312571224 sdb
		//   8       17   11839844 sdb1
		// 253        0  287232116 dm-0
		//
		// linux - Get simple list of all disks
		// https://unix.stackexchange.com/questions/360582/get-simple-list-of-all-disks
		// # ls /dev/sd*
		// /dev/sda  /dev/sda1
		//
		// linux - get physical hdd's list in c
		// https://stackoverflow.com/a/19570104
		// FILE *fp = popen("fdisk -l | grep \"Disk /\" | awk '{print $2};' | sed 's/://'", "r");
		// while(fgets(path, sizeof(path) -1,fp) != NULL)
		// pclose(fp);
		//
		// $> df
		// [Filesystem   1K-blocks      Used Available Use% Mounted on]
		// [udev           1911276         0   1911276   0% /dev]
		// [/dev/sda2     36023000  12525564  21654236  37% /]
		// [tmpfs          1953392     11204   1942188   1% /dev/shm]
		// [/dev/sdb1     11522688   8200756   2729944  76% /mnt]
		// [/dev/sda1       664280      7828    656452   2% /boot/efi]
		//
		char bfr2[256];  //FILE *fp2 = popen("fdisk -l | grep \"Disk /\" | awk '{print $2};' | sed 's/://'", "r");
		FILE* fp2 = popen("df", "r");
		for( int ii3=0, iDisk=0; fgets( bfr2, sizeof(bfr2)-1, fp2 ); ii3++ ){
			std::string line2 = hf_trim_stdstring<char>( bfr2, "\r\n");
			std::vector<std::string> words2;
			hf_explode( line2.c_str(), "\x20", words2, "\r\n\x20\t", -1 );
			words2.erase( std::remove_if(
					words2.begin(), words2.end(),
					[]( const std::string& a )->bool{
							return a.empty();
					}), words2.end() );
			if( !words2.empty() && *words2.begin() == "Filesystem" ){
				continue;
			}
			FU_DiskVolume dv3;
			dv3.nOrderNr    = iDisk++;
			dv3.bAccessible = 1;
			{
				auto a = words2.begin();
				for( int ii4=0; a != words2.end(); ++a, ii4++ ){
					if( ii4 == 0 ){
						dv3.srPath = *a;
						dv3.srShortName = *a;
					}else if( ii4 == 1 ){   //size in 1k blocks
						dv3.uSize = HfArgs("%1").arg(a->c_str()).toUint64(10);
						dv3.uSize *= 1024;
					}
				}
			}
			outp->push_back( dv3 );
		}
		pclose(fp2);
#	endif
	return 1;
}

