#include "fu2_ulcfg.h"
#include <cctype>    //std::isalpha()

bool FU_CmdUlCfgInject::exec2()
{

	return 00;
}
std::vector<uint8_t> FU_CmdUlCfgInject::
createUlCfgEntry( const char* szTitle, std::string srGameIdWthDot ) //static
{
	assert( szTitle );
	assert( *szTitle );
	assert( !srGameIdWthDot.empty() );
	assert( srGameIdWthDot.size() == 11 );  //eg. "SLUS_123.45"
	std::vector<uint8_t> outp;
	size_t len2 = std::min<size_t>( 31, std::strlen( szTitle ) );
	for( size_t ii2 = 0; ii2 < len2; ii2++ ){
		outp.push_back( static_cast<char>( szTitle[ii2] ) );
	}
	outp.resize( 32, 0 );
	// eg. "ul.SLUS_209.46"
	static const std::string data2 = "ul.";
	static const std::vector<uint8_t> data3 = { 0, 0x05, 0x14, 0,0,0,0, 0x08, };
	outp.insert( outp.end(), data2.begin(), data2.end() );
	outp.insert( outp.end(), srGameIdWthDot.begin(), srGameIdWthDot.end() );
	outp.insert( outp.end(), data3.begin(), data3.end() );
	assert( outp.size() == 54 );
	outp.resize( 64, 0 );
	return outp;
}
/// Extracts PS2 title-id from input string.
/// Extracted is first encountered match.
/// Finds fe.: "SLUS_123.45".
///            "SLUS12345".
///            "SLUS_12345".
///         or "SLUS123.45",
///    bot not "SLUSx_123.45".
/// \param outp - returns title-id as string/value pair.
///               Eg. string set to "SLUS" and value set to 12345.
/// \param aPosEnd - optional, position where id has been found. begin and end index.
bool FU_CmdUlCfgInject::
getPs2GameIdFromText( std::string inp, std::pair<std::string,uint32_t>* outp, std::pair<size_t,size_t>* aPosEnd, std::string* srGmIdOut )
{
	std::string letters2, digits2;
	std::pair<std::string,uint32_t> outp3, *outp2 = ( outp ? outp : &outp3 );
	std::pair<size_t,size_t> aPosEnd3, *aPosEnd2 = ( aPosEnd ? aPosEnd : &aPosEnd3 );
	*aPosEnd2 = { inp.size(), inp.size(), };
	for( size_t ii2=0; ii2 < inp.size(); ii2++ ){
		if( ii2 && ii2+1 < inp.size() ){  // detect if no at the begin and non-alpha-char leads alpth-char.
			if( !std::isalpha( inp[ii2+0] ) && std::isalpha( inp[ii2+1] ) ){
				ii2 += 1;
			}else{
				continue;
			}
		}
		if( ii2+5 < inp.size() ){
			bool bOk2 = (
				std::isalpha( inp[ii2+0] ) &&
				std::isalpha( inp[ii2+1] ) &&
				std::isalpha( inp[ii2+2] ) &&
				std::isalpha( inp[ii2+3] ) &&
				!std::isalpha( inp[ii2+4] ) );
			if(bOk2){
				letters2.insert( letters2.end(), inp.begin() + ii2, inp.begin() + ii2+4 );
				//const size_t iStart = ii2;
				aPosEnd2->first = ii2;
				ii2 += 4;
				ii2 += ( std::strchr("_-.\x20", inp[ii2] ) ? 1 : 0 );
				if( ii2+3 < inp.size() ){ // part "123.45" or "12345".
					bool bOk3 = (
						std::isdigit( inp[ii2+0] ) &&
						std::isdigit( inp[ii2+1] ) &&
						std::isdigit( inp[ii2+2] ) );
					if( bOk3 ){
						digits2.insert( digits2.end(), inp.begin() + ii2, inp.begin() + ii2+3 );
						ii2 += 3;
						ii2 += ( inp[ii2] == '.' ? 1 : 0 );
						if( ii2+1 < inp.size() ){
							bool bOk4 = (
								std::isdigit( inp[ii2+0] ) &&
								std::isdigit( inp[ii2+1] ) );
							if( bOk4 ){
								aPosEnd2->second = ii2+2;
								digits2.insert( digits2.end(), inp.begin() + ii2, inp.begin() + ii2+2 );
								break;
							}
						}
					}
				}
			}
		}
	}
	*outp2 = {
		letters2,
		static_cast<uint32_t>( std::strtoul( digits2.c_str(), 0, 10 ) ), };
	if( srGmIdOut ){
		*srGmIdOut = ( outp2->first + "_" +
			std::to_string( uint32_t(outp2->second / 100) ) + "." +
			std::to_string( uint32_t(outp2->second % 100) ) );
	}
	return !digits2.empty();
}
/// Adds game entry to the "ul.cfg" file.
/// Does not check if same entry already exists.
/// \param srTitlePlusGmId -
///              expected to contain game title and title-id.
///              eg. "GT4 Concept SLUS_123.45"
/// \param srUlCfgPath - path to the "ul.cfg" file.
/// \param err         - optional, message on error.
bool FU_CmdUlCfgInject::
addUlCfgTitleFromText( std::string srTitlePlusGmId, std::string srUlCfgPath, std::string* err )
{
	std::string err3, *err2 = (err ? err : &err3);
	if( !hf_FileExists( srUlCfgPath.c_str() ) ){
		*err2 = "File not found.";
		return 0;
	}
	std::pair<size_t,size_t> aBgnEnd;
	std::string srGmId;
	if( !getPs2GameIdFromText( srTitlePlusGmId, 0, &aBgnEnd, &srGmId ) ){
		*err2 = "Game title ID not found.";
		return 0;
	}
	std::string srTitle;
	{
		std::string a, b;
		a = srTitlePlusGmId.substr( 0, aBgnEnd.first );
		b = srTitlePlusGmId.substr( aBgnEnd.second, std::string::npos );
		srTitle = (
			( b.empty() ?
				a : hf_rtrim_stdstring( a.c_str(), "_-.\x20") ) +
			( a.empty() ?
				b : hf_ltrim_stdstring( b.c_str(), "_-.\x20") ) );
		srTitle = hf_rtrim_stdstring( srTitle.c_str(), "_-.\x20");
	}
	if( srTitle.empty() ){
		*err2 = "Game title yields empty text.";
		return 0;
	}
	auto aEntry = createUlCfgEntry( srTitle.c_str(), srGmId.c_str() );
	if( aEntry.empty() ){
		*err2 = "Failed creating config entry.";
		return 0;
	}
	bool rs2 = hf_PutFileBytes( srUlCfgPath.c_str(),
			&aEntry[0], (int)aEntry.size(), HF_EPFBF_APPEND );
	if(!rs2){
		*err2 = "Failed writing file data.";
		return 0;
	}
	*err2 = "OK.";
	return 1;
}
